from pathlib import Path
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings

STORE_DIR = r"D:\mypptAgent\kb_store"

embeddings = HuggingFaceEmbeddings(model_name="BAAI/bge-small-zh-v1.5")
vs = FAISS.load_local(str(STORE_DIR), embeddings, allow_dangerous_deserialization=True)

query = "新能源汽车的未来"
hits = vs.similarity_search_with_score(query, k=4)

for i, (doc, score) in enumerate(hits, start=1):
    print(f"\n--- Hit {i} | score={score:.4f} ---")
    print("source:", doc.metadata.get("source"), "page:", doc.metadata.get("page"))
    print(doc.page_content[:200])
