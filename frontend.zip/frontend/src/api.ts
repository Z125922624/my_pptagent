export type GenerateRequest = {
  prompt: string
  ensure_image: boolean
  concurrency: number
}

const DEFAULT_BASE_URL = 'http://localhost:8000'

export async function generatePptx(req: GenerateRequest, baseUrl = DEFAULT_BASE_URL) {
  const res = await fetch(`${baseUrl}/api/generate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req),
  })

  // 后端失败会返回 JSON
  const ct = res.headers.get('content-type') || ''
  if (!res.ok) {
    if (ct.includes('application/json')) {
      const data = await res.json().catch(() => ({}))
      throw new Error(data?.error || data?.detail || `HTTP ${res.status}`)
    }
    throw new Error(`HTTP ${res.status}`)
  }

  // 成功：返回pptx二进制
  const blob = await res.blob()

  // 尝试从 header 里读文件名
  const dispo = res.headers.get('content-disposition') || ''
  const m = /filename\*=UTF-8''([^;]+)|filename="?([^";]+)"?/i.exec(dispo)
  const filename = decodeURIComponent((m?.[1] || m?.[2] || 'deck.pptx').trim())

  return { blob, filename }
}
