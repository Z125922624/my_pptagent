# render_pptx.py
from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple


from pptx.util import Inches
from pptx.dml.color import RGBColor

from pptx.enum.text import PP_ALIGN


from pptx.enum.text import MSO_ANCHOR


# =========================
# Theme / Tokens
# =========================
PRIMARY = RGBColor(25, 55, 120)      # 主色
LIGHT_BG = RGBColor(245, 247, 250)   # 浅底
TEXT = RGBColor(30, 30, 30)
MUTED = RGBColor(110, 110, 110)
BORDER = RGBColor(220, 225, 230)

FONT_NAME = "PingFang SC"  # Windows 没有也没事，PPT 会 fallback

SLIDE_W = Inches(13.33)
SLIDE_H = Inches(7.5)

# Left content region (avoid overlapping right image panel)
LEFT_X = 0.6
LEFT_W = 7.2

RIGHT_X = 8.1
RIGHT_W = 4.9

TOP_BAR_H = 0.92
FOOTER_Y = 7.12


# =========================
# Project root finder (关键：解决相对路径找不到图片)
# =========================
def _find_project_root(start: Path) -> Path:
    """
    从 start 向上找包含 kb/images 的目录，找不到就退回 start
    """
    cur = start
    for _ in range(10):
        if (cur / "kb" / "images").exists():
            return cur
        if cur.parent == cur:
            break
        cur = cur.parent
    return start


PROJECT_ROOT = _find_project_root(Path(__file__).resolve().parent)


# =========================
# Layout helpers
# =========================
def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))
# =========================
# Consulting-style atoms
# =========================

def _get_block(blocks: list, kind: str) -> Optional[dict]:
    for b in blocks or []:
        if isinstance(b, dict) and b.get("kind") == kind:
            return b
    return None
import ast

def _safe_parse_obj(x):
    """content 可能是 dict，也可能是 "{'a':1}" 这种字符串；尽量转成 dict"""
    if x is None:
        return None
    if isinstance(x, dict):
        return x
    if isinstance(x, str):
        s = x.strip()
        if not s:
            return None
        # 先尝试 python dict 字面量
        try:
            obj = ast.literal_eval(s)
            if isinstance(obj, dict):
                return obj
        except Exception:
            pass
        # 再尝试很宽松的 JSON（如果你后面改成 JSON 了也兼容）
        try:
            import json
            obj = json.loads(s)
            if isinstance(obj, dict):
                return obj
        except Exception:
            pass
    return None

def _get_fact(blocks: list):
    """返回 dict: {label,value,note,source} 或 None"""
    for b in blocks or []:
        if getattr(b, "kind", None) == "fact":
            c = _safe_parse_obj(getattr(b, "content", None))
            if c:
                return c
    return None

def _get_example(blocks: list):
    """返回 dict: {title,text} 或 None"""
    for b in blocks or []:
        if getattr(b, "kind", None) == "example":
            c = _safe_parse_obj(getattr(b, "content", None))
            if c:
                return c
    return None


def _get_image_content(blocks: list) -> Tuple[str, str]:
    b = _get_block(blocks, "image")
    if not b:
        return "", ""
    c = b.get("content") or {}
    return (c.get("path", "") or "", c.get("caption", "") or "")


def _get_callout_text(slide_obj: dict, blocks: list) -> str:
    callout_block = _get_block(blocks, "callout")
    t = (callout_block.get("content") if callout_block else "") or ""
    if not t:
        t = _infer_callout(slide_obj)
    return (t or "").strip()


def _get_bullets(blocks: list, fallback_max: int = 5) -> list[str]:
    b = _get_block(blocks, "bullets")
    if b and isinstance(b.get("content"), list):
        arr = [x.strip() for x in b["content"] if isinstance(x, str) and x.strip()]
        if arr:
            return arr[:fallback_max]

    # fallback: cards -> 用 title / text 组装成 bullets（更“充实”）
    c = _get_block(blocks, "cards")
    if c and isinstance(c.get("content"), list):
        out = []
        for it in c["content"][:fallback_max]:
            if not isinstance(it, dict):
                continue
            title = (it.get("title") or "").strip()
            text = (it.get("text") or "").strip()
            if title and text:
                out.append(f"{title}：{text}")
            elif title:
                out.append(title)
            elif text:
                out.append(text)
        if out:
            return out[:fallback_max]

    # fallback: text
    t = _get_block(blocks, "text")
    if t and isinstance(t.get("content"), str):
        s = t["content"].strip()
        if s:
            return [s][:fallback_max]

    return []


def _cards_normalize(items: list) -> list[dict]:
    out = []
    for it in items or []:
        if not isinstance(it, dict):
            continue
        title = (it.get("title") or "").strip()
        text = (it.get("text") or "").strip()
        bullets = it.get("bullets") or []

        # 统一 bullets
        if isinstance(bullets, list):
            bullets = [str(x).strip() for x in bullets if str(x).strip()]
        else:
            bullets = []

        # ✅ 如果没给 bullets，但 text 里是 "• ..." 多行，把它解析成 bullets（供网格卡片用）
        if not bullets and text:
            lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
            parsed = []
            for ln in lines:
                ln = ln.lstrip("•-· ").strip()
                if ln:
                    parsed.append(ln)
            bullets = parsed

        out.append({"title": title, "text": text, "bullets": bullets})
    return out


def add_bg_bands(slide, theme: str = "blue"):
    """
    在内容区加上下色带/浅底块，提升“模板感”
    """
    if theme == "purple":
        top = RGBColor(92, 86, 176)
        bottom = RGBColor(66, 62, 140)
        faint = RGBColor(246, 246, 252)
    else:
        top = RGBColor(20, 55, 120)
        bottom = RGBColor(16, 45, 98)
        faint = RGBColor(246, 248, 252)

    # 浅底铺满（不盖 header）
    bg = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.RECTANGLE,
        Inches(0), Inches(TOP_BAR_H), SLIDE_W, SLIDE_H - Inches(TOP_BAR_H)
    )
    bg.fill.solid()
    bg.fill.fore_color.rgb = faint
    bg.line.fill.background()

    # 顶部细色带（在 header 下方）
    band1 = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.RECTANGLE,
        Inches(0), Inches(TOP_BAR_H), SLIDE_W, Inches(0.12)
    )
    band1.fill.solid()
    band1.fill.fore_color.rgb = top
    band1.line.fill.background()

    # 底部色带
    band2 = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.RECTANGLE,
        Inches(0), Inches(7.28), SLIDE_W, Inches(0.22)
    )
    band2.fill.solid()
    band2.fill.fore_color.rgb = bottom
    band2.line.fill.background()


def add_pill(slide, x: float, y: float, w: float, h: float, text: str,
             fill: RGBColor = RGBColor(235, 241, 255), line: RGBColor = RGBColor(180, 198, 240),
             color: RGBColor = PRIMARY, font_size: int = 14):
    """
    胶囊标题（参考图右侧卡片那种）
    x/y/w/h 单位：英寸
    """
    pill = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
        Inches(x), Inches(y), Inches(w), Inches(h)
    )
    pill.fill.solid()
    pill.fill.fore_color.rgb = fill
    pill.line.color.rgb = line
    pill.line.width = Pt(1)

    tx = slide.shapes.add_textbox(Inches(x), Inches(y + 0.02), Inches(w), Inches(h))
    tf = tx.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.text = text
    p.alignment = PP_ALIGN.CENTER
    _set_font(p, font_size, bold=True, color=color)

def _get_explain_text(blocks: list) -> str:
    """
    给 C 模板左上卡片的 small_text 用：
    优先 example.text，其次 fact.note，其次 bullets 拼一句。
    """
    ex = _get_example(blocks)
    if ex and (ex.get("text") or "").strip():
        return (ex.get("text") or "").strip()

    ft = _get_fact(blocks)
    if ft and (ft.get("note") or "").strip():
        return (ft.get("note") or "").strip()

    # bullets 兜底：取前2条拼一句
    bs = _get_bullets(blocks, 4) or []
    bs = [b.strip() for b in bs if isinstance(b, str) and b.strip()]
    if bs:
        s = "；".join(bs[:2])
        return (s + "。") if not s.endswith(("。", "！", "？")) else s

    return ""

def add_icon_badge(slide, x: float, y: float, size: float = 0.62,
                   fill: RGBColor = RGBColor(74, 120, 220),
                   glyph: str = "✓", glyph_color: RGBColor = RGBColor(255, 255, 255)):
    """
    圆徽章 icon（不依赖字体图标库）
    """
    badge = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.OVAL,
        Inches(x), Inches(y), Inches(size), Inches(size)
    )
    badge.fill.solid()
    badge.fill.fore_color.rgb = fill
    badge.line.fill.background()

    tx = slide.shapes.add_textbox(Inches(x), Inches(y - 0.01), Inches(size), Inches(size))
    tf = tx.text_frame
    tf.clear()
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.text = glyph
    p.alignment = PP_ALIGN.CENTER
    _set_font(p, 18, bold=True, color=glyph_color)



from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_AUTO_SHAPE_TYPE
from PIL import Image


def add_image_frame(
    slide,
    x: float, y: float, w: float, h: float,
    path: str,
    shadow: bool = True,
    caption: str = "",
    caption_h: float = 0.85,
    fit: str = "contain",      # contain=不裁剪完整显示
    padding: float = 0.18,     # 内边距（越小越“贴边”）
    corner_radius: bool = True
):
    """
    白框 + 阴影 + 图片 + 可选 caption
    - fit="contain": 保持比例完整显示（不裁剪）
    坐标单位：英寸
    """

    # ---------- 参数兜底 ----------
    path = (path or "").strip()
    fit = (fit or "contain").lower()
    if fit not in ("contain", "cover"):
        fit = "contain"

    BORDER = RGBColor(220, 225, 235)
    CARD_BG = RGBColor(255, 255, 255)
    SHADOW = RGBColor(170, 170, 200)
    CAPTION_COLOR = RGBColor(90, 90, 90)
    PLACEHOLDER = RGBColor(245, 247, 250)

    # ---------- 0) 解析路径（兼容你已有 _resolve_image_path） ----------
    img_path = path
    if " _resolve_image_path" in globals():
        # 保险：避免你没定义时报错
        try:
            img_path = _resolve_image_path(path)
        except Exception:
            img_path = path

    # ---------- 1) 阴影 ----------
    if shadow:
        sh = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE if corner_radius else MSO_AUTO_SHAPE_TYPE.RECTANGLE,
            Inches(x + 0.08), Inches(y + 0.08),
            Inches(w), Inches(h)
        )
        sh.fill.solid()
        sh.fill.fore_color.rgb = SHADOW
        sh.fill.transparency = 0.60
        sh.line.fill.background()

    # ---------- 2) 外框 ----------
    frame = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE if corner_radius else MSO_AUTO_SHAPE_TYPE.RECTANGLE,
        Inches(x), Inches(y),
        Inches(w), Inches(h)
    )
    frame.fill.solid()
    frame.fill.fore_color.rgb = CARD_BG
    frame.line.color.rgb = BORDER
    frame.line.width = Pt(1.5)

    # ---------- 3) 计算图片可用区域（给 caption 留空间） ----------
    inner_x = x + padding
    inner_y = y + padding
    inner_w = max(0.2, w - 2 * padding)
    inner_h = max(0.2, h - 2 * padding)

    if caption:
        inner_h = max(0.2, inner_h - caption_h)

    # ---------- 4) 放图（不裁剪：contain） ----------
    if img_path and os.path.exists(img_path):
        try:
            im = Image.open(img_path)
            iw, ih = im.size
            im.close()

            img_ar = iw / max(1, ih)
            box_ar = inner_w / max(1e-6, inner_h)

            # contain：完整显示
            if img_ar >= box_ar:
                pic_w = inner_w
                pic_h = inner_w / img_ar
            else:
                pic_h = inner_h
                pic_w = inner_h * img_ar

            pic_x = inner_x + (inner_w - pic_w) / 2
            pic_y = inner_y + (inner_h - pic_h) / 2

            slide.shapes.add_picture(
                img_path,
                Inches(pic_x), Inches(pic_y),
                width=Inches(pic_w),
                height=Inches(pic_h)
            )
        except Exception:
            # 读图失败就画占位
            ph = slide.shapes.add_shape(
                MSO_AUTO_SHAPE_TYPE.RECTANGLE,
                Inches(inner_x), Inches(inner_y),
                Inches(inner_w), Inches(inner_h)
            )
            ph.fill.solid()
            ph.fill.fore_color.rgb = PLACEHOLDER
            ph.line.color.rgb = BORDER
    else:
        # 没图：占位
        ph = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.RECTANGLE,
            Inches(inner_x), Inches(inner_y),
            Inches(inner_w), Inches(inner_h)
        )
        ph.fill.solid()
        ph.fill.fore_color.rgb = PLACEHOLDER
        ph.line.color.rgb = BORDER

    # ---------- 5) caption ----------
    if caption:
        tx = slide.shapes.add_textbox(
            Inches(x + padding),
            Inches(y + h - caption_h - padding),
            Inches(w - 2 * padding),
            Inches(caption_h)
        )
        tf = tx.text_frame
        tf.clear()
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.text = caption.strip()
        p.font.size = Pt(12)
        p.font.color.rgb = CAPTION_COLOR


def _split_two_lines(text: str, target_ratio: float = 0.5) -> str:
    """
    将过长的文本自动拆成两行：
    - 优先在中间附近寻找分隔符切开
    - 找不到就按字符对半切
    返回带 '\n' 的字符串（若不需要拆分则原样返回）
    """
    if not text:
        return text
    t = text.strip()
    # 太短不拆
    if len(t) <= 12:
        return t

    # 目标切点
    mid = int(len(t) * target_ratio)

    # 在中间附近找最佳分隔符
    seps = ["，", "、", "：", "；", "。", "/", "-", " ", "（", "）"]
    window = max(3, len(t) // 6)  # 搜索窗口大小

    best_idx = None
    best_dist = 10**9

    for i, ch in enumerate(t):
        if ch in seps:
            dist = abs(i - mid)
            if dist <= window and dist < best_dist and 2 <= i <= len(t) - 3:
                best_idx = i
                best_dist = dist

    if best_idx is not None:
        left = t[:best_idx].rstrip("，、：；。/ -（ ）")
        right = t[best_idx + 1 :].lstrip("，、：；。/ -（ ）")
        if left and right:
            return left + "\n" + right

    # 没找到分隔符：硬切
    cut = _clamp(mid, 4, len(t) - 4)
    cut = int(cut)
    return t[:cut] + "\n" + t[cut:]


def _resolve_image_path(p: str) -> Optional[str]:
    """支持绝对/相对路径；重点：优先 PROJECT_ROOT / p。"""
    if not p:
        return None

    path = Path(p)

    # 1) 绝对路径
    if path.is_absolute() and path.is_file():
        return str(path)

    # 2) 项目根目录拼接（✅最关键）
    root_try = PROJECT_ROOT / p
    if root_try.is_file():
        return str(root_try)

    # 3) CWD 拼接
    cwd_try = Path(os.getcwd()) / p
    if cwd_try.is_file():
        return str(cwd_try)

    # 4) 脚本目录拼接（兜底）
    script_dir = Path(__file__).resolve().parent
    try1 = script_dir / p
    if try1.is_file():
        return str(try1)
    try2 = script_dir.parent / p
    if try2.is_file():
        return str(try2)

    print(f"[WARN] image not found: {p} | PROJECT_ROOT={PROJECT_ROOT} | CWD={os.getcwd()}")
    return None


def _set_font(paragraph, size: int, bold: bool = False, color: Optional[RGBColor] = None, name: str = FONT_NAME):
    paragraph.font.size = Pt(size)
    paragraph.font.bold = bold
    paragraph.font.name = name
    if color is not None:
        paragraph.font.color.rgb = color


def _set_run_font(run, size: int, bold: bool = False, color: Optional[RGBColor] = None, name: str = FONT_NAME):
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.name = name
    if color is not None:
        run.font.color.rgb = color


def _estimate_text_density(lines: List[str]) -> int:
    """粗略评估文本密度，用于动态降字号/增高：字符总数 + 行数权重"""
    total_chars = sum(len(s) for s in lines)
    return total_chars + len(lines) * 20


def _choose_bullet_font_size(bullets: List[str]) -> int:
    """
    动态选择 bullets 字号，避免溢出。
    经验规则：密度越高字号越小。
    """
    d = _estimate_text_density(bullets)
    if d <= 180:
        return 22
    if d <= 260:
        return 20
    if d <= 340:
        return 18
    return 16
import math

def _estimate_chars_per_line(box_w_in: float, font_size_pt: int) -> int:
    """
    粗略估算一行能放多少“中文字符”（含标点）。
    经验：中文字宽接近 1em；用 0.95~1.05 的系数都行，这里取 1.0 稳一点。
    """
    if font_size_pt <= 0:
        return 12
    usable_pt = box_w_in * 72  # inches -> points
    return max(8, int(usable_pt / (font_size_pt * 1.0)))


def _estimate_wrapped_lines(text: str, chars_per_line: int) -> int:
    """
    估算某段文字换行后会占几行（按字符数近似）。
    """
    if not text:
        return 1
    t = text.strip()
    # 允许你主动写了 '\n' 强制断行
    parts = t.split("\n")
    lines = 0
    for part in parts:
        n = max(1, len(part))
        lines += max(1, math.ceil(n / max(1, chars_per_line)))
    return max(1, lines)


def _choose_card_text_size(text: str) -> int:
    """cards/process 内文字字号自适应"""
    if not text:
        return 12
    n = len(text)
    if n <= 20:
        return 16
    if n <= 40:
        return 14
    return 13


# =========================
# UI Components
# =========================
def add_header_bar(slide, title: str):
    bar = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.RECTANGLE,
        Inches(0), Inches(0), SLIDE_W, Inches(TOP_BAR_H)
    )
    bar.fill.solid()
    bar.fill.fore_color.rgb = PRIMARY
    bar.line.fill.background()

    tx = slide.shapes.add_textbox(Inches(0.6), Inches(0.18), Inches(12.5), Inches(0.6))
    tf = tx.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    p.text = title
    _set_font(p, 28, bold=True, color=RGBColor(255, 255, 255))
    p.alignment = PP_ALIGN.LEFT

def add_feature_card(slide, x: float, y: float, w: float, h: float, title: str, body: str,
                     badge_glyph: str = "✓"):
    """
    参考你图1：右侧纵向卡片
    """
    # 外框
    card = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
        Inches(x), Inches(y), Inches(w), Inches(h)
    )
    card.fill.solid()
    card.fill.fore_color.rgb = RGBColor(255, 255, 255)
    card.line.color.rgb = RGBColor(225, 230, 240)
    card.line.width = Pt(1.25)

    # icon badge
    add_icon_badge(slide, x + 0.25, y + 0.28, size=0.62, glyph=badge_glyph)

    # pill title
    add_pill(slide, x + 1.05, y + 0.25, w - 1.30, 0.42, title,
             fill=RGBColor(238, 244, 255), line=RGBColor(186, 204, 245), color=PRIMARY, font_size=14)

    # body
    tx = slide.shapes.add_textbox(Inches(x + 1.05), Inches(y + 0.75), Inches(w - 1.30), Inches(h - 0.95))
    tf = tx.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.TOP

    p = tf.paragraphs[0]
    p.text = body
    p.alignment = PP_ALIGN.LEFT
    _set_font(p, 12, color=TEXT)

def add_footer(slide, page_no: int, total: int, sources: List[str]):
    # 页码
    pn = slide.shapes.add_textbox(Inches(12.3), Inches(FOOTER_Y), Inches(1.0), Inches(0.3))
    tf = pn.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    p.text = f"{page_no}/{total}"
    _set_font(p, 10, color=MUTED)
    p.alignment = PP_ALIGN.RIGHT

    # Sources（简写文件名）
    if sources:
        short = []
        for s in sources:
            short.append(str(s).split("\\")[-1].split("/")[-1])
        src_text = "Sources: " + ", ".join(sorted(set(short)))

        st = slide.shapes.add_textbox(Inches(0.6), Inches(FOOTER_Y), Inches(11.5), Inches(0.3))
        tf = st.text_frame
        tf.clear()
        p = tf.paragraphs[0]
        p.text = src_text
        _set_font(p, 10, color=MUTED)
        p.alignment = PP_ALIGN.LEFT


def add_callout(slide, text: str):
    if not text:
        return

    box = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
        Inches(LEFT_X), Inches(1.06), Inches(LEFT_W), Inches(0.86)
    )
    box.fill.solid()
    box.fill.fore_color.rgb = LIGHT_BG
    box.line.color.rgb = BORDER
    box.line.width = Pt(1.5)

    tx = slide.shapes.add_textbox(Inches(LEFT_X + 0.25), Inches(1.18), Inches(LEFT_W - 0.4), Inches(0.65))
    tf = tx.text_frame
    tf.clear()
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    _set_font(p, 18, bold=True, color=TEXT)
    p.alignment = PP_ALIGN.LEFT

def add_bullets_card(slide, bullets: List[str], top=2.05, bottom_limit: Optional[float] = None) -> Optional[float]:
    """
    ✅ 大白底 bullets 卡片（尽量大，但如果 bottom_limit 给了就不越界）
    - 每条前面：• + 编号（• 1. ）
    - 自动换行 + 悬挂缩进（换行后正文对齐）
    返回：卡片底部 y（英寸）
    """
    if not bullets:
        return None

    bullets = [b.strip() for b in bullets if b and b.strip()]
    if not bullets:
        return None

    bullets = bullets[:7]

    top = float(top)

    # 允许的最底部（默认贴近 footer 上方）
    bottom_margin = 0.35
    default_bottom = float(FOOTER_Y) - bottom_margin

    if bottom_limit is None:
        bottom_limit = default_bottom
    else:
        bottom_limit = float(min(bottom_limit, default_bottom))

    # 计算高度：尽量大，但不超过 bottom_limit
    h = max(2.6, bottom_limit - top)
    if h <= 1.2:
        return None

    # 卡片
    card = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
        Inches(LEFT_X), Inches(top), Inches(LEFT_W), Inches(h)
    )
    card.fill.solid()
    card.fill.fore_color.rgb = RGBColor(255, 255, 255)
    card.line.color.rgb = BORDER
    card.line.width = Pt(2)

    # 文本框（padding 大一点）
    tx = slide.shapes.add_textbox(
        Inches(LEFT_X + 0.32), Inches(top + 0.30),
        Inches(LEFT_W - 0.64), Inches(h - 0.55)
    )
    tf = tx.text_frame
    tf.clear()
    tf.word_wrap = True

    # 字号：轻量降字号防溢出（你想固定也可以）
    font_size = _choose_bullet_font_size(bullets)
    font_size = max(16, min(20, font_size))

    # 悬挂缩进：• 1. 挂左，正文换行后对齐
    left_indent = Inches(0.55)
    hanging = Inches(0.38)

    for i, b in enumerate(bullets, start=1):
        p = tf.paragraphs[0] if i == 1 else tf.add_paragraph()
        p.level = 0
        p.line_spacing = 1.08
        p.space_after = Pt(4)  # 稍微收紧一点

        p.left_indent = left_indent
        p.first_line_indent = -hanging

        r1 = p.add_run()
        r1.text = f"• {i}. "
        _set_run_font(r1, font_size, bold=True, color=PRIMARY)

        r2 = p.add_run()
        r2.text = b
        _set_run_font(r2, font_size, bold=False, color=TEXT)

    return float(top + h)







def add_cards(slide, cards: List[Dict[str, str]], top: float = 3.45, height: float = 1.65):
    """
    ✅ cards 做大一点（height 默认更大）
    """
    if not cards:
        return

    left = Inches(LEFT_X)
    top_in = Inches(top)
    w = Inches(LEFT_W)

    cols = min(3, len(cards))
    gap = Inches(0.25)
    card_w = (w - gap * (cols - 1)) / cols
    card_h = Inches(height)

    for i, c in enumerate(cards[:cols]):
        x = left + i * (card_w + gap)
        y = top_in

        shape = slide.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE, x, y, card_w, card_h)
        shape.fill.solid()
        shape.fill.fore_color.rgb = LIGHT_BG
        shape.line.color.rgb = BORDER
        shape.line.width = Pt(1.5)

        t = slide.shapes.add_textbox(x + Inches(0.25), y + Inches(0.18), card_w - Inches(0.5), card_h - Inches(0.32))
        tf = t.text_frame
        tf.word_wrap = True
        tf.clear()
        tf.margin_left = Inches(0.06)
        tf.margin_right = Inches(0.06)
        tf.margin_top = Inches(0.03)
        tf.margin_bottom = Inches(0.03)

        title = (c.get("title") or "").strip()
        text = (c.get("text") or "").strip()

        p1 = tf.paragraphs[0]
        p1.text = title
        _set_font(p1, 15, bold=True, color=PRIMARY)

        if text:
            p2 = tf.add_paragraph()
            p2.text = text
            _set_font(p2, _choose_card_text_size(text), color=TEXT)


def add_process_vertical_arrows(slide, steps: List[str], top: float = 3.45):
    """
    ✅ 你最终要的 process：
    - 卡片“纵向排布”（上->下）
    - 卡片之间用“箭头”连接（向下箭头）
    - 每个卡片更大（宽/高都更大）
    - 文字自动换行；过长时自动在中间加换行（_split_two_lines）
    - 自动计算高度，避免溢出左侧背景/footer
    """
    if not steps:
        return

    steps = [s.strip() for s in steps if s and s.strip()]
    steps = steps[:5]
    if not steps:
        return

    # 可用区域：从 top 到 footer 之前
    max_available_h = FOOTER_Y - 0.15 - top
    if max_available_h <= 1.5:
        return

    left = Inches(LEFT_X)
    w = Inches(LEFT_W)
    y = top

    n = len(steps)

    # 箭头 + 间距
    gap_y = 0.16            # 卡片与箭头的“呼吸”
    arrow_h = 0.28
    arrow_w = 0.55

    # 总“非卡片高度”
    non_card_total = (n - 1) * (gap_y + arrow_h + gap_y)

    # 卡片高度：自动分配
    # 设定最小/最大，避免太扁或太大
    card_h = (max_available_h - non_card_total) / n
    card_h = _clamp(card_h, 1.05, 1.45)  # ✅ 你想更大可把 1.45 调到 1.55

    # 如果 card_h 被 clamp 到最大后仍可能超：重新计算 y 逻辑时靠 footer 也不会超
    # 但如果太挤，宁可再压一点 arrow_gap
    #（这里保持简单稳定）

    # textbox padding（更大）
    pad_x = 0.26
    pad_y = 0.14

    for i, raw in enumerate(steps, start=1):
        # 强制“中间断行”+ word_wrap 兜底
        content = _split_two_lines(raw)

        # 卡片
        card = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
            left, Inches(y),
            w, Inches(card_h)
        )
        card.fill.solid()
        card.fill.fore_color.rgb = LIGHT_BG
        card.line.color.rgb = BORDER
        card.line.width = Pt(2)

        # 文本框（更大）
        tx = slide.shapes.add_textbox(
            left + Inches(pad_x),
            Inches(y + pad_y),
            w - Inches(pad_x * 2),
            Inches(card_h - pad_y * 2)
        )
        tf = tx.text_frame
        tf.clear()
        tf.word_wrap = True
        tf.auto_size = MSO_AUTO_SIZE.TEXT_TO_FIT_SHAPE  # ✅ 尽量防溢出（支持则生效）

        tf.margin_left = Inches(0.05)
        tf.margin_right = Inches(0.05)
        tf.margin_top = Inches(0.02)
        tf.margin_bottom = Inches(0.02)

        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        p.line_spacing = 1.08

        # 编号（主色加粗） + 正文（黑色加粗）
        r1 = p.add_run()
        r1.text = f"{i}. "
        _set_run_font(r1, 16, bold=True, color=PRIMARY)

        r2 = p.add_run()
        r2.text = content
        _set_run_font(r2, 16, bold=True, color=TEXT)

        # 下箭头（最后一个不画）
        if i < n:
            y_arrow = y + card_h + gap_y
            arr = slide.shapes.add_shape(
                MSO_AUTO_SHAPE_TYPE.DOWN_ARROW,
                left + w / 2 - Inches(arrow_w / 2),
                Inches(y_arrow),
                Inches(arrow_w),
                Inches(arrow_h)
            )
            arr.fill.solid()
            arr.fill.fore_color.rgb = PRIMARY
            arr.line.fill.background()

            y = y_arrow + arrow_h + gap_y
        else:
            y = y + card_h


def add_quote(slide, quote: str, source: str = "", top: float = 2.05) -> Optional[float]:
    """可选：quote block，返回底部 y"""
    if not quote:
        return None

    max_available_h = FOOTER_Y - 0.15 - top
    h = min(5.35, max_available_h)

    card = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
        Inches(LEFT_X), Inches(top), Inches(LEFT_W), Inches(h)
    )
    card.fill.solid()
    card.fill.fore_color.rgb = RGBColor(255, 255, 255)
    card.line.color.rgb = BORDER
    card.line.width = Pt(2)

    tx = slide.shapes.add_textbox(Inches(LEFT_X + 0.35), Inches(top + 0.35), Inches(LEFT_W - 0.7), Inches(h - 0.7))
    tf = tx.text_frame
    tf.word_wrap = True
    tf.clear()

    p = tf.paragraphs[0]
    p.text = f"“{quote}”"
    _set_font(p, 20, bold=True, color=TEXT)

    if source:
        p2 = tf.add_paragraph()
        p2.text = f"— {source}"
        _set_font(p2, 12, color=MUTED)
        p2.space_before = Pt(12)

    return float(top + h)


def add_image_panel(slide, path: str, caption: Optional[str]):
    """右侧图片面板 + caption（固定版式，稳定）"""
    img_path = _resolve_image_path(path)

    panel = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
        Inches(RIGHT_X), Inches(1.55), Inches(RIGHT_W), Inches(5.35)
    )
    panel.fill.solid()
    panel.fill.fore_color.rgb = RGBColor(255, 255, 255)
    panel.line.color.rgb = BORDER
    panel.line.width = Pt(2)

    if not img_path:
        ph = slide.shapes.add_textbox(Inches(RIGHT_X + 0.25), Inches(3.6), Inches(RIGHT_W - 0.5), Inches(0.6))
        tf = ph.text_frame
        tf.clear()
        p = tf.paragraphs[0]
        p.text = "（图片待补充）"
        _set_font(p, 14, color=MUTED)
        p.alignment = PP_ALIGN.CENTER
        return

    pic = slide.shapes.add_picture(
        img_path,
        Inches(RIGHT_X + 0.25), Inches(1.8),
        width=Inches(RIGHT_W - 0.5), height=Inches(3.3)
    )
    try:
        pic.line.color.rgb = BORDER
        pic.line.width = Pt(1)
    except Exception:
        pass

    if caption:
        cap = slide.shapes.add_textbox(Inches(RIGHT_X + 0.25), Inches(5.25), Inches(RIGHT_W - 0.5), Inches(1.4))
        tf = cap.text_frame
        tf.word_wrap = True
        tf.clear()
        p = tf.paragraphs[0]
        p.text = caption
        _set_font(p, 12, color=MUTED)
        p.alignment = PP_ALIGN.LEFT

def add_image_panel_dual(slide, img1: Dict[str, str], img2: Dict[str, str]):
    """
    右侧双图：上下两张，各自可带 caption（可选）
    """
    panel = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
        Inches(RIGHT_X), Inches(1.55), Inches(RIGHT_W), Inches(5.35)
    )
    panel.fill.solid()
    panel.fill.fore_color.rgb = RGBColor(255, 255, 255)
    panel.line.color.rgb = BORDER
    panel.line.width = Pt(2)

    # 上图
    p1 = _resolve_image_path(img1.get("path", ""))
    if p1:
        slide.shapes.add_picture(
            p1,
            Inches(RIGHT_X + 0.25), Inches(1.75),
            width=Inches(RIGHT_W - 0.5), height=Inches(2.45)
        )
    else:
        ph = slide.shapes.add_textbox(Inches(RIGHT_X + 0.25), Inches(2.55), Inches(RIGHT_W - 0.5), Inches(0.5))
        tf = ph.text_frame
        tf.clear()
        tf.paragraphs[0].text = "（图片待补充）"
        _set_font(tf.paragraphs[0], 12, color=MUTED)
        tf.paragraphs[0].alignment = PP_ALIGN.CENTER

    # 下图
    p2 = _resolve_image_path(img2.get("path", ""))
    if p2:
        slide.shapes.add_picture(
            p2,
            Inches(RIGHT_X + 0.25), Inches(4.25),
            width=Inches(RIGHT_W - 0.5), height=Inches(2.45)
        )
    else:
        ph = slide.shapes.add_textbox(Inches(RIGHT_X + 0.25), Inches(5.05), Inches(RIGHT_W - 0.5), Inches(0.5))
        tf = ph.text_frame
        tf.clear()
        tf.paragraphs[0].text = "（图片待补充）"
        _set_font(tf.paragraphs[0], 12, color=MUTED)
        tf.paragraphs[0].alignment = PP_ALIGN.CENTER

def _set_speaker_notes(slide, notes: str):
    if not notes:
        return
    notes_slide = slide.notes_slide
    tf = notes_slide.notes_text_frame
    tf.text = notes


def _extract_blocks(slide_obj: Dict[str, Any]) -> List[Dict[str, Any]]:
    return slide_obj.get("blocks", []) or []


def _find_blocks(blocks: List[Dict[str, Any]], kind: str) -> List[Dict[str, Any]]:
    return [b for b in (blocks or []) if b.get("kind") == kind]


def _get_image_contents(blocks: List[Dict[str, Any]], max_n: int = 2) -> List[Dict[str, str]]:
    """
    返回最多 max_n 个图片 content： [{"path": "...", "caption": "..."}, ...]
    兼容：
    - 多个 kind="image"
    - 单个 kind="image"
    """
    imgs = []
    for b in _find_blocks(blocks, "image"):
        c = b.get("content") or {}
        if isinstance(c, dict):
            p = (c.get("path") or "").strip()
            cap = (c.get("caption") or "").strip()
            imgs.append({"path": p, "caption": cap})
        if len(imgs) >= max_n:
            break
    return imgs



def _infer_callout(slide_obj: Dict[str, Any]) -> str:
    notes = (slide_obj.get("speaker_notes") or "").strip()
    if not notes:
        return ""
    line = notes.split("\n")[0].strip()
    if "。" in line:
        line = line.split("。")[0] + "。"
    return line
# ====== 在 render_pptx.py 里新增：cards/fact/example 的绘制 + 模板选择器 ======


from pptx.enum.text import MSO_AUTO_SIZE  # 可选：若你的环境可用


def _get_block(blocks, kind: str):
    for b in blocks or []:
        if b.get("kind") == kind:
            return b
    return None


def _cards_normalize(cards_raw):
    """兼容两种 cards 数据：{title,text} 或 {title,bullets}"""
    out = []
    for c in (cards_raw or []):
        title = (c.get("title") or "").strip()
        bullets = c.get("bullets")
        text = (c.get("text") or "").strip()
        if isinstance(bullets, list) and bullets:
            bullets2 = [str(x).strip() for x in bullets if str(x).strip()]
            out.append({"title": title, "bullets": bullets2[:3]})
        elif text:
            out.append({"title": title, "bullets": [text]})
        else:
            out.append({"title": title, "bullets": []})
    return out


def add_fact_badge(slide, fact: dict, left: float, top: float, w: float, h: float):
    """咨询风：一个小数据/要点徽章（左侧底部或右侧角落都行）"""
    if not fact:
        return
    label = (fact.get("label") or "").strip()
    value = (fact.get("value") or "").strip()
    note = (fact.get("note") or "").strip()

    shape = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
        Inches(left), Inches(top), Inches(w), Inches(h)
    )
    shape.fill.solid()
    shape.fill.fore_color.rgb = LIGHT_BG
    shape.line.color.rgb = BORDER
    shape.line.width = Pt(1.5)

    tx = slide.shapes.add_textbox(Inches(left + 0.2), Inches(top + 0.12), Inches(w - 0.35), Inches(h - 0.2))
    tf = tx.text_frame
    tf.clear()
    tf.word_wrap = True

    p1 = tf.paragraphs[0]
    p1.text = label if label else "Fact"
    _set_font(p1, 12, bold=True, color=PRIMARY)

    p2 = tf.add_paragraph()
    p2.text = value
    _set_font(p2, 16, bold=True, color=TEXT)

    if note:
        p3 = tf.add_paragraph()
        p3.text = note
        _set_font(p3, 11, color=MUTED)


def add_example_box(slide, ex: dict, left: float, top: float, w: float, h: float):
    """咨询风：例子用浅底卡片承载，1~2句"""
    if not ex:
        return
    title = (ex.get("title") or "例子").strip()
    text = (ex.get("text") or "").strip()
    if not text:
        return

    box = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
        Inches(left), Inches(top), Inches(w), Inches(h)
    )
    box.fill.solid()
    box.fill.fore_color.rgb = RGBColor(255, 255, 255)
    box.line.color.rgb = BORDER
    box.line.width = Pt(1.5)

    tx = slide.shapes.add_textbox(Inches(left + 0.25), Inches(top + 0.15), Inches(w - 0.45), Inches(h - 0.25))
    tf = tx.text_frame
    tf.clear()
    tf.word_wrap = True

    p1 = tf.paragraphs[0]
    p1.text = title
    _set_font(p1, 12, bold=True, color=PRIMARY)

    p2 = tf.add_paragraph()
    p2.text = text
    _set_font(p2, 12, color=TEXT)


def add_cards_grid_2x2(slide, cards: list, left: float, top: float, w: float, h: float):
    """
    模板A用：2x2 网格卡片（最多4张）
    """
    cards = _cards_normalize(cards)[:4]
    if not cards:
        return

    rows = 2
    cols = 2
    gap = 0.18
    card_w = (w - gap) / cols
    card_h = (h - gap) / rows

    for i, c in enumerate(cards):
        r = i // cols
        cc = i % cols
        x = left + cc * (card_w + gap)
        y = top + r * (card_h + gap)

        shape = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
            Inches(x), Inches(y), Inches(card_w), Inches(card_h)
        )
        shape.fill.solid()
        shape.fill.fore_color.rgb = LIGHT_BG
        shape.line.color.rgb = BORDER
        shape.line.width = Pt(1.25)

        tx = slide.shapes.add_textbox(Inches(x + 0.18), Inches(y + 0.14), Inches(card_w - 0.32), Inches(card_h - 0.22))
        tf = tx.text_frame
        tf.clear()
        tf.word_wrap = True

        p1 = tf.paragraphs[0]
        p1.text = c.get("title", "")
        _set_font(p1, 13, bold=True, color=PRIMARY)

        for b in (c.get("bullets") or [])[:2]:
            p = tf.add_paragraph()
            p.text = f"{b}"
            _set_font(p, 16, color=TEXT)
            p.space_after = Pt(2)


def add_cards_row_3(slide, cards: list, left: float, top: float, w: float, h: float):
    """
    模板B用：横向3张大卡片（最多3张）
    """
    cards = _cards_normalize(cards)[:3]
    if not cards:
        return

    gap = 0.22
    cols = len(cards)
    card_w = (w - gap * (cols - 1)) / cols
    card_h = h

    for i, c in enumerate(cards):
        x = left + i * (card_w + gap)
        y = top

        shape = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
            Inches(x), Inches(y), Inches(card_w), Inches(card_h)
        )
        shape.fill.solid()
        shape.fill.fore_color.rgb = LIGHT_BG
        shape.line.color.rgb = BORDER
        shape.line.width = Pt(1.25)

        tx = slide.shapes.add_textbox(Inches(x + 0.2), Inches(y + 0.16), Inches(card_w - 0.36), Inches(card_h - 0.22))
        tf = tx.text_frame
        tf.clear()
        tf.word_wrap = True

        p1 = tf.paragraphs[0]
        p1.text = c.get("title", "")
        _set_font(p1, 18, bold=True, color=PRIMARY)

        for b in (c.get("bullets") or [])[:3]:
            p = tf.add_paragraph()
            p.text = f"• {b}"
            _set_font(p, 12, color=TEXT)
            p.space_after = Pt(2)
import random

def choose_template_id(slide_obj: dict) -> str:
    """
    A：企业简介风（左大图卡 + 右3能力卡）
    B：城市历史风（双图 + 左侧要点）
    C：紫色责任风（左2大信息卡 + 右2图）
    """
    tid = (slide_obj.get("template_id") or "").strip().upper()
    if tid in ("A", "B", "C"):
        return tid

    # 没指定就按 slide_no 固定随机（每页不同，且可复现）
    seed = int(slide_obj.get("slide_no") or 0)
    r = random.Random(seed)
    return r.choice(["A", "B", "C"])



def render_template_A(slide, slide_obj: dict, blocks: list):
    """
    参考图1：企业简介页
    左：大图卡 + 底部信息条（强结论）
    右：3 张纵向能力卡（icon + pill + 文本）
    """
    add_bg_bands(slide, theme="blue")

    callout = _get_callout_text(slide_obj, blocks)
    img_path, img_cap = _get_image_content(blocks)

    cards_block = _get_block(blocks, "cards")
    cards = _cards_normalize((cards_block or {}).get("content") or [])
    # 右侧只取 3 张，没 cards 就用 bullets 拆
    if not cards:
        bullets = _get_bullets(blocks, 3)
        cards = [{"title": f"要点 {i+1}", "text": bullets[i] if i < len(bullets) else "", "bullets": []} for i in range(min(3, len(bullets)))]

    # 区域参数（全幅）
    top = 1.45
    bottom_limit = FOOTER_Y - 0.20

    left_x, left_w = 0.70, 7.35
    right_x, right_w = 8.35, 4.45
    height = bottom_limit - top

    # 左大图卡（caption 你也可以隐藏，这里保留一行更像“咨询注释”）
    add_image_frame(
        slide,
        x=left_x, y=top, w=left_w, h=height,
        path=img_path,
        caption=img_cap[:60] if img_cap else "",
        caption_h=0.85
    )

    # 左图卡底部信息条：强结论（更高级，替代灰色 callout 框）
    info_h = 1.20
    info = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
        Inches(left_x + 0.35), Inches(top + height - info_h - 0.25),
        Inches(left_w - 0.70), Inches(info_h)
    )
    info.fill.solid()
    info.fill.fore_color.rgb = RGBColor(255, 255, 255)
    info.line.fill.background()

    tx = slide.shapes.add_textbox(
        Inches(left_x + 0.55), Inches(top + height - info_h - 0.13),
        Inches(left_w - 1.10), Inches(info_h - 0.25)
    )
    tf = tx.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.text = callout or "关键结论：本页结论待补充"
    p.alignment = PP_ALIGN.LEFT
    _set_font(p, 18, bold=True, color=TEXT)

    # 右侧 3 能力卡
    card_h = (height - 0.32) / 3
    gap = 0.16
    card_h = (height - 2 * gap) / 3

    glyphs = ["</>", "♥", "↗"]
    for i in range(3):
        if i >= len(cards):
            break
        y = top + i * (card_h + gap)
        title = cards[i].get("title") or f"模块 {i+1}"
        body = cards[i].get("text") or ""
        if not body and cards[i].get("bullets"):
            body = "；".join(cards[i]["bullets"][:2])
        add_feature_card(slide, right_x, y, right_w, card_h, title, body, badge_glyph=glyphs[i % len(glyphs)])

def render_template_B(slide, slide_obj: dict, blocks: list):
    """
    Template B：更“满”的版本
    左上：强结论/小标题 + bullets
    右上：大图（更大更高）
    左下：第二图（更大）
    右下：要点回顾卡（贴底，保持稳定）
    """
    add_bg_bands(slide, theme="blue")

    callout = _get_callout_text(slide_obj, blocks)
    bullets = _get_bullets(blocks, 6)

    imgs = _get_image_contents(blocks, max_n=2)
    img1 = imgs[0] if len(imgs) >= 1 else {"path": "", "caption": ""}
    img2 = imgs[1] if len(imgs) >= 2 else img1

    # ===== 页面可用高度 =====
    top = 1.35                       # 原 1.45：上移一点，给内容多点空间
    bottom_limit = FOOTER_Y - 0.15   # 原 -0.20：再多一点点
    height = bottom_limit - top

    # ===== 横向布局：左窄右宽 =====
    gap = 0.25                       # 原来视觉更松
    left_x = 0.75
    left_w = 5.60                    # 原 6.40：左侧变窄，右侧变宽（图片立刻更大）
    right_x = left_x + left_w + gap
    right_w = 12.85 - right_x        # 保持你原来的页面宽基准

    # ===== 纵向布局：右上大图 + 右下卡；左上文本 + 左下大图 =====
    # 右下卡：固定贴底，保持稳定（你说“右下保持不动”）
    recap_h = 2.20                   # 右下卡高度（可 2.0~2.4 微调）
    recap_y = bottom_limit - recap_h

    # 右上大图：吃掉右侧剩余空间（更高）
    right_img_y = top + 0.00
    right_img_h = (recap_y - right_img_y) - 0.18  # 留一点缝

    # 左上文本区：压低一点（更低、更紧凑）
    left_text_h = 2.00               # 左上文本整体高度（含标题+bullets）
    left_text_y = top - 0.05

    # 左下图：占满左侧剩余空间（更大）
    left_img_y = left_text_y + left_text_h + 0.15
    left_img_h = bottom_limit - left_img_y

    # ========= 左上：小标题 =========
    sub = slide.shapes.add_textbox(
        Inches(left_x), Inches(left_text_y-0.3),
        Inches(left_w), Inches(0.55)
    )
    tf = sub.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    p.text = (callout[:20] + "…") if callout and len(callout) > 20 else (callout or "本页要点")
    _set_font(p, 20, bold=True, color=PRIMARY)
    p.alignment = PP_ALIGN.LEFT

    # ========= 左上：bullets（更紧凑一点） =========
    bx = slide.shapes.add_textbox(
        Inches(left_x), Inches(left_text_y + 0.1),
        Inches(left_w), Inches(left_text_h - 0.62)
    )
    tf = bx.text_frame
    tf.clear()
    tf.word_wrap = True
    for i, b in enumerate(bullets[:3], start=1):
        p = tf.paragraphs[0] if i == 1 else tf.add_paragraph()
        p.level = 0
        p.text = f"• {b}"
        _set_font(p, 13, color=TEXT)
        p.space_after = Pt(4)

    # ========= 右上：大图（更宽更高，尽量占满） =========
    add_image_frame(
        slide,
        x=right_x, y=right_img_y, w=right_w, h=right_img_h,
        path=img1.get("path", ""),
        caption="",
        caption_h=0.0
    )

    # ========= 左下：第二图（更大，占满左侧剩余空间） =========
    add_image_frame(
        slide,
        x=left_x, y=left_img_y, w=left_w, h=left_img_h,
        path=img2.get("path", ""),
        caption="",
        caption_h=0.0
    )

    # ========= 右下：要点回顾（贴底） =========
    box = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
        Inches(right_x), Inches(recap_y),
        Inches(right_w), Inches(recap_h)
    )
    box.fill.solid()
    box.fill.fore_color.rgb = RGBColor(255, 255, 255)
    box.line.color.rgb = RGBColor(225, 230, 240)
    box.line.width = Pt(1.25)

    add_pill(
        slide,
        right_x + 0.35, recap_y + 0.15,
        right_w - 0.70, 0.42,
        "要点回顾",
        fill=RGBColor(238, 244, 255),
        line=RGBColor(186, 204, 245),
        color=PRIMARY,
        font_size=14
    )

    tx = slide.shapes.add_textbox(
        Inches(right_x + 0.35), Inches(recap_y + 0.62),
        Inches(right_w - 0.70), Inches(recap_h - 0.80)
    )
    tf = tx.text_frame
    tf.clear()
    tf.word_wrap = True

    # 这里用 bullet 更像“回顾卡”
    show = bullets[:2] if bullets else []
    if not show:
        show = [callout] if callout else ["（待补充）"]

    for i, t in enumerate(show, start=1):
        p = tf.paragraphs[0] if i == 1 else tf.add_paragraph()
        p.text = f"• {t}"
        _set_font(p, 12, color=TEXT)
        p.space_after = Pt(3)


def render_template_C(slide, slide_obj: dict, blocks: list):
    add_bg_bands(slide, theme="purple")

    callout = _get_callout_text(slide_obj, blocks)
    bullets = _get_bullets(blocks, 8)
    fact = _get_fact(blocks)
    example = _get_example(blocks)

    imgs = _get_image_contents(blocks, max_n=2)
    img1 = imgs[0] if len(imgs) >= 1 else {"path": "", "caption": ""}
    img2 = imgs[1] if len(imgs) >= 2 else img1

    top = 1.45
    bottom_limit = FOOTER_Y - 0.20
    height = bottom_limit - top

    def _small_info_card(x, y, w, h, pill_text, lines, footer=""):
        sh = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
            Inches(x + 0.08), Inches(y + 0.08), Inches(w), Inches(h)
        )
        sh.fill.solid()
        sh.fill.fore_color.rgb = RGBColor(170, 170, 200)
        sh.fill.transparency = 0.60
        sh.line.fill.background()

        card = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
            Inches(x), Inches(y), Inches(w), Inches(h)
        )
        card.fill.solid()
        card.fill.fore_color.rgb = RGBColor(255, 255, 255)
        card.line.fill.background()

        add_pill(slide, x + 0.30, y + 0.18, min(2.5, w - 0.6), 0.46, pill_text,
                 fill=RGBColor(222, 220, 245), line=RGBColor(210, 208, 238),
                 color=PRIMARY, font_size=14)

        tx = slide.shapes.add_textbox(Inches(x + 0.30), Inches(y + 0.78), Inches(w - 0.60), Inches(h - 1.00))
        tf = tx.text_frame
        tf.clear()
        tf.word_wrap = True

        for i, t in enumerate(lines[:6]):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.text = f"• {t}"
            _set_font(p, 12, color=TEXT)
            p.space_after = Pt(2)

        if footer:
            p2 = tf.add_paragraph()
            p2.text = footer
            _set_font(p2, 11, color=MUTED)

    def _big_info_card(x, y, w, h, pill_text, main_text, small_text=""):
            sh = slide.shapes.add_shape(
                MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
                Inches(x + 0.08), Inches(y + 0.08), Inches(w), Inches(h)
            )
            sh.fill.solid()
            sh.fill.fore_color.rgb = RGBColor(170, 170, 200)
            sh.fill.transparency = 0.60
            sh.line.fill.background()

            card = slide.shapes.add_shape(
                MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
                Inches(x), Inches(y), Inches(w), Inches(h)
            )
            card.fill.solid()
            card.fill.fore_color.rgb = RGBColor(255, 255, 255)
            card.line.fill.background()

            add_pill(
                slide, x + 0.30, y + 0.18, min(2.9, w - 0.6), 0.46,
                pill_text,
                fill=RGBColor(222, 220, 245),
                line=RGBColor(210, 208, 238),
                color=PRIMARY,
                font_size=14
            )

            tx = slide.shapes.add_textbox(
                Inches(x + 0.30), Inches(y + 0.68),
                Inches(w - 0.60), Inches(max(0.6, h - 0.78))
            )
            tf = tx.text_frame
            tf.clear()
            tf.word_wrap = True

            p = tf.paragraphs[0]
            p.text = main_text or "关键结论待补充"
            _set_font(p, 17, bold=True, color=TEXT)
            p.space_after = Pt(6)

            # ✅ small_text 不要写死：来自大模型（你已用 _get_explain_text）
            if small_text:
                p2 = tf.add_paragraph()
                p2.text = small_text
                _set_font(p2, 12, color=MUTED)
    left_x = 0.75
    gap = 0.35
    left_w = 6.55
    right_x = left_x + left_w + gap
    right_w = 12.85 - right_x

    row_gap = 0.25
    top_h = 1.5
    bottom_h = height - top_h - row_gap
    # --- 左上文本卡（保持你的 _big_info_card）---
    small_text = _get_explain_text(blocks)
    s=small_text.split("\n")
    _big_info_card(left_x, top, left_w, top_h,
                   pill_text="行动纲领",
                   main_text=callout or "关键结论待补充",
                   small_text=s[0])

    # ✅ 右下卡片的位置（你说要“保持不动”）
    rb_x = right_x + 0.10
    rb_y = top + top_h + row_gap + 0.65
    rb_w = right_w - 0.15
    rb_h = bottom_h - 0.75

    # ✅ 右上图片：高度拉长到“贴近右下卡片顶”
    img_gap = 0.18
    rt_x = right_x
    rt_y = top
    rt_w = right_w
    rt_h = max(1.2, (rb_y - img_gap) - rt_y)   # ✅ 关键：把空白吃掉

    add_image_frame(
        slide,
        x=rt_x, y=rt_y, w=rt_w, h=rt_h,
        path=img1.get("path", ""),
        caption="",
        fit="contain"   # ✅ 不裁剪
    )

    # --- 左下大图（仍在左列，尽量大）---
    add_image_frame(
        slide,
        x=left_x, y=top + top_h + row_gap, w=left_w, h=bottom_h,
        path=img2.get("path", ""),
        caption=(img2.get("caption", "") or "")[:40],
        fit="contain"   # ✅ 不裁剪
    )

    # --- 右下文本卡（不动）---
    lines = []
    if fact:
        lines.append(f"{fact.get('label','关键事实')}：{fact.get('value','')}".strip("："))
        note = (fact.get("note") or "").strip()
        if note:
            lines.append(note)
    for b in bullets[:2]:
        if b and b not in lines:
            lines.append(b)
    if not lines:
        lines = ["回顾核心结论", "明确落地场景", "提出下一步问题"]

    footer = ""
    if example:
        footer = f"例：{(example.get('title') or '').strip()} {(example.get('text') or '').strip()}"[:45]
    else:
        footer = "互动：你怎么看？"

    _small_info_card(
        x=rb_x, y=rb_y, w=rb_w, h=rb_h,
        pill_text="要点与互动",
        lines=lines,
        footer=footer
    )

    add_footer(slide, slide_obj.get("slide_no", 1), slide_obj.get("total", 1), slide_obj.get("citations", []))


def _extract_toc_titles(slides: list, max_n: int = 8) -> list[str]:
    """从 deck['slides'] 中提取每页 title（跳过 title/toc 页）。"""
    out: list[str] = []
    for s in slides or []:
        if not isinstance(s, dict):
            continue
        st = (s.get("slide_type") or "content").lower()
        if st in ("title", "toc"):
            continue
        t = (s.get("title") or "").strip()
        if t:
            out.append(t)
    return out[:max_n]

def render_template_TOC(slide, deck_title_or_obj, toc_titles=None, slide_no: int = 1, total: int = 1, citations=None):
    """
    目录页（对称 + 干净）：
    - 中间圆形：deck_title
    - 两侧：蓝底白字条形目录（仅标题，不留空白）
    兼容两种调用：
      1) render_template_TOC(slide, deck_title:str, toc_titles:list)
      2) render_template_TOC(slide, slide_obj:dict)  # 老版本
    """
    if citations is None:
        citations = []

    # --- 兼容参数 ---
    if isinstance(deck_title_or_obj, dict):
        slide_obj = deck_title_or_obj
        deck_title = (slide_obj.get("deck_title") or slide_obj.get("title") or "").strip()
        toc_titles = (slide_obj.get("toc_titles") or []) if toc_titles is None else toc_titles
    else:
        deck_title = (deck_title_or_obj or "").strip()
        toc_titles = toc_titles or []

    add_bg_bands(slide, theme="blue")

    # ---------- 标题 ----------
    top = 1.45
    title_box = slide.shapes.add_textbox(Inches(0.75), Inches(top - 0.32), Inches(5.5), Inches(0.7))
    tf = title_box.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    p.text = "目录"
    _set_font(p, 36, bold=True, color=PRIMARY)
    p.alignment = PP_ALIGN.LEFT

    # ---------- 画布尺寸与中心 ----------
    slide_w = float(getattr(SLIDE_W, "inches", 13.33))
    bottom_limit = float(FOOTER_Y) - 0.35
    body_h = bottom_limit - top
    center_x = slide_w / 2.0

    # ---------- 中间圆 ----------
    circle_d = 2.5
    circle_x = center_x - circle_d / 2.0
    circle_y = top + (body_h - circle_d) / 2.0

    sh = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.OVAL,
        Inches(circle_x + 0.10), Inches(circle_y + 0.10),
        Inches(circle_d), Inches(circle_d)
    )
    sh.fill.solid()
    sh.fill.fore_color.rgb = RGBColor(120, 120, 150)
    sh.fill.transparency = 0.65
    sh.line.fill.background()

    c = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.OVAL,
        Inches(circle_x), Inches(circle_y),
        Inches(circle_d), Inches(circle_d)
    )
    c.fill.solid()
    c.fill.fore_color.rgb = PRIMARY
    c.line.fill.background()

    tx = slide.shapes.add_textbox(Inches(circle_x + 0.25), Inches(circle_y + 0.35), Inches(circle_d - 0.5), Inches(circle_d - 0.7))
    tf = tx.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.text = deck_title or "概览"
    _set_font(p, 20, bold=True, color=RGBColor(255, 255, 255))
    p.alignment = PP_ALIGN.CENTER

    # ---------- 左右条形目录（蓝底白字，无白色框，不留小字空白） ----------
    titles = [t.strip() for t in (toc_titles or []) if str(t).strip()]
    max_n = 8
    titles = titles[:max_n]

    n_left = (len(titles) + 1) // 2
    left_titles = titles[:n_left]
    right_titles = titles[n_left:]

    margin_x = 0.65
    bar_w = 4.6
    bar_h = 0.68
    gap_y = 0.58

    left_x = margin_x
    right_x = slide_w - margin_x - bar_w

    # 垂直居中排布
    rows = max(len(left_titles), len(right_titles), 1)
    total_h = rows * bar_h + (rows - 1) * gap_y
    start_y = top + (body_h - total_h) / 2.0

    def _toc_bar(x, y, text):
        bar = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
            Inches(x), Inches(y),
            Inches(bar_w), Inches(bar_h)
        )
        bar.fill.solid()
        bar.fill.fore_color.rgb = PRIMARY
        bar.line.fill.background()

        t = slide.shapes.add_textbox(Inches(x + 0.28), Inches(y + 0.12), Inches(bar_w - 0.56), Inches(bar_h - 0.18))
        tf = t.text_frame
        tf.clear()
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.text = text
        _set_font(p, 18, bold=True, color=RGBColor(255, 255, 255))
        p.alignment = PP_ALIGN.LEFT

    for i, t in enumerate(left_titles):
        y = start_y + i * (bar_h + gap_y)
        _toc_bar(left_x, y, t)

    for i, t in enumerate(right_titles):
        y = start_y + i * (bar_h + gap_y)
        _toc_bar(right_x, y, t)

    add_footer(slide, slide_no, total, citations)
def render_template_COVER(slide, deck: dict):
    """
    首页 Cover（参考你图）：
    - 白底
    - 左侧蓝色块
    - 左侧六边形“PPT”徽标（阴影 + 浅灰外环 + 蓝色内核 + 白字）
    - 中间灰色标题带：蓝色字（title）
    - 下方蓝色胶囊：白字（时间 | 讲师）
    """
    slide_w = float(getattr(SLIDE_W, "inches", 13.33))
    slide_h = float(getattr(SLIDE_H, "inches", 7.5))

    # --- 背景白底 ---
    bg = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.RECTANGLE,
        Inches(0), Inches(0), SLIDE_W, SLIDE_H
    )
    bg.fill.solid()
    bg.fill.fore_color.rgb = RGBColor(255, 255, 255)
    bg.line.fill.background()

    # --- 左侧蓝色块 ---
    left_blue_w = 4.4
    left = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.RECTANGLE,
        Inches(0), Inches(0), Inches(left_blue_w), Inches(slide_h)
    )
    left.fill.solid()
    left.fill.fore_color.rgb = PRIMARY
    left.line.fill.background()

    # --- 斜切浅灰层（装饰） ---
    diag = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.PARALLELOGRAM,
        Inches(left_blue_w - 1.0), Inches(-0.8),
        Inches(3.2), Inches(slide_h + 1.6)
    )
    diag.fill.solid()
    diag.fill.fore_color.rgb = RGBColor(240, 240, 240)
    diag.line.fill.background()

    # =========================================================
    # ✅ 六边形 PPT Logo（你之前旧版有，这里加回去）
    # =========================================================
    # 位置/大小：根据你的参考图大概在左侧蓝块中部偏上
    # 你也可以微调 logo_x/logo_y/logo_size 来对齐你的审美
    logo_x = 1.55
    logo_y = 1.8
    logo_size = 2.35

    # 1) 阴影
    sh = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.HEXAGON,
        Inches(logo_x + 0.10), Inches(logo_y + 0.12),
        Inches(logo_size), Inches(logo_size)
    )
    sh.fill.solid()
    sh.fill.fore_color.rgb = RGBColor(0, 0, 0)
    sh.fill.transparency = 0.85
    sh.line.fill.background()

    # 2) 浅灰外环
    hex_bg = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.HEXAGON,
        Inches(logo_x), Inches(logo_y),
        Inches(logo_size), Inches(logo_size)
    )
    hex_bg.fill.solid()
    hex_bg.fill.fore_color.rgb = RGBColor(245, 245, 245)
    hex_bg.line.fill.background()

    # 3) 蓝色内核（略小一点，形成外环效果）
    inner_pad = 0.18
    hex_fg = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.HEXAGON,
        Inches(logo_x + inner_pad), Inches(logo_y + inner_pad),
        Inches(logo_size - 2 * inner_pad), Inches(logo_size - 2 * inner_pad)
    )
    hex_fg.fill.solid()
    hex_fg.fill.fore_color.rgb = PRIMARY
    hex_fg.line.fill.background()

    # 4) “PPT”白字
    tx = slide.shapes.add_textbox(
        Inches(logo_x + inner_pad),
        Inches(logo_y + inner_pad + 0.55),
        Inches(logo_size - 2 * inner_pad),
        Inches(logo_size - 2 * inner_pad)
    )
    tf = tx.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    p.text = "PPT"
    p.alignment = PP_ALIGN.CENTER
    _set_font(p, 44, bold=True, color=RGBColor(255, 255, 255))

    # --- 中间灰色标题带（蓝字） ---
    band_x = left_blue_w + 0.8
    band_y = 2.35
    band_w = slide_w - band_x - 0.8
    band_h = 1.55

    band = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
        Inches(band_x), Inches(band_y),
        Inches(band_w), Inches(band_h)
    )
    band.fill.solid()
    band.fill.fore_color.rgb = RGBColor(235, 235, 235)
    band.line.fill.background()

    title = (deck.get("title") or "title").strip()

    title_box = slide.shapes.add_textbox(
        Inches(band_x + 0.55), Inches(band_y + 0.25),
        Inches(band_w - 1.1), Inches(0.95)
    )
    tf = title_box.text_frame
    tf.clear()
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = title
    _set_font(p, 40, bold=True, color=PRIMARY)
    p.alignment = PP_ALIGN.LEFT

    # --- 时间 & 讲师（蓝底白字胶囊）---
    date_text = (deck.get("date") or deck.get("time") or "").strip()
    speaker = (deck.get("speaker") or deck.get("lecturer") or "").strip()

    if not date_text and not speaker:
        meta = "时间：____  |  讲师：____"
    elif date_text and speaker:
        meta = f"时间：{date_text}  |  讲师：{speaker}"
    elif date_text:
        meta = f"时间：{date_text}"
    else:
        meta = f"讲师：{speaker}"

    add_pill(
        slide,
        x=band_x + 2.5, y=band_y + band_h + 1.15,
        w=min(5.0, band_w - 3.0), h=0.62,
        text=meta,
        fill=PRIMARY, line=PRIMARY,
        color=RGBColor(255, 255, 255),
        font_size=16
    )

def render_deck(deck: dict, out_path: str ):
    """
    生成 PPT：
    - 第 1 页：封面（COVER）
    - 第 2 页：目录（TOC）
    - 第 3 页起：原先 deck["slides"] 的所有页面（完全沿用你原来的模板渲染，不破坏功能）
    并保证：除封面外，每页都有顶部蓝色标题栏（add_header_bar）。
    """
    import os
    from pptx import Presentation

    prs = Presentation()
    prs.slide_width = SLIDE_W
    prs.slide_height = SLIDE_H

    slides = deck.get("slides") or []
    deck_title = (
        deck.get("title")
        or deck.get("deck_title")
        or deck.get("topic")
        or "title"
    )

    # -------- 目录标题（一般 8 页）--------
    toc_titles = []
    for s in slides:
        t = (s.get("title") or s.get("topic") or s.get("name") or "").strip()
        tid = choose_template_id(s)
        if t:
            toc_titles.append(t)
    toc_titles = toc_titles[:]

    total_pages = len(slides) + 2
    blank_layout = prs.slide_layouts[6]  # 空白

    # -------- 1) 第 1 页：封面 --------
    cover_slide = prs.slides.add_slide(blank_layout)
    # ✅ 你项目里的 render_template_COVER 应该是 (slide, deck) 这种签名
    render_template_COVER(cover_slide, deck)
    add_footer(cover_slide, 1, total_pages, [])

    # -------- 2) 第 2 页：目录 --------
    toc_slide = prs.slides.add_slide(blank_layout)
    add_header_bar(toc_slide, deck_title)
    render_template_TOC(toc_slide, deck_title, toc_titles)
    add_footer(toc_slide, 2, total_pages, [])

    # -------- 3) 第 3 页起：内容页（保留你原逻辑）--------
    for idx, s in enumerate(slides):
        page_no = idx + 3
        slide = prs.slides.add_slide(blank_layout)

        # ✅ 顶部蓝条
        add_header_bar(slide, deck_title)

        blocks = s.get("blocks") or []
        slide_type = (s.get("slide_type") or s.get("type") or "").strip().lower()
        template = (s.get("template_id") or s.get("tpl") or s.get("layout") or "").strip().upper()

        # ============================================================
        # ✅ 关键：title 页必须走你原来的 inline 逻辑（四卡片那套）
        # 你把你之前那段：
        #   if slide_type == "title":
        #       ...
        #       continue
        # 原封不动粘贴到这里（把 slide / idx / s / blocks / total_pages 对应好）
        # ============================================================
        if slide_type == "title":
            # --------- 下面这段请你用你项目“原来的 title 页逻辑”替换 ---------
            # 例：你之前那段包含 deck_subtitle / add_callout / add_image_panel /
            #     idx==1 的 cards_grid_2x2 / add_footer / speaker_notes / continue
            #
            # ⚠️ 注意：你这里的页码是 page_no，不是 idx
            #
            # === 你原逻辑粘贴开始 ===
            # deck_subtitle = deck.get("subtitle") or deck.get("deck_subtitle") or ""
            # if deck_subtitle: ...
            # callout_text = _get_callout_text(s, blocks)
            # add_callout(slide, callout_text)
            # img_path, img_cap = _get_image_content(blocks)
            # add_image_panel(slide, img_path or "", img_cap or "")
            # if idx == 0:  # 这里 idx 是内容页 idx，从 0 开始
            #     cards_block = _get_block(blocks, "cards")
            #     if cards_block and ...:
            #         add_cards_grid_2x2(...)
            #     else:
            #         ...
            # add_footer(slide, page_no, total_pages, s.get("citations", []) or [])
            # _set_speaker_notes(slide, s.get("speaker_notes",""))
            # continue
            # === 你原逻辑粘贴结束 ===

            # 临时兜底：如果你还没粘贴，至少别炸
            render_template_A(slide, s, blocks)
        else:
            # --------- 其他页：按 A/B/C 模板渲染（不引入不存在的 TITLE 函数）---------
            if template in ("A", "TEMPLATE_A"):
                render_template_A(slide, s, blocks)
            elif template in ("B", "TEMPLATE_B"):
                render_template_B(slide, s, blocks)
            elif template in ("C", "TEMPLATE_C"):
                render_template_C(slide, s, blocks)
            else:
                render_template_A(slide, s, blocks)

        # 页脚
        add_footer(
            slide,
            page_no,
            total_pages,
            s.get("citations", []) or s.get("sources", []) or []
        )

    # -------- 4) 保存：避免 output.pptx 被占用 --------
    try:
        prs.save(out_path)
        return out_path
    except PermissionError:
        base, ext = os.path.splitext(out_path)
        alt_path = f"{base}_new{ext or '.pptx'}"
        prs.save(alt_path)
        return alt_path


if __name__ == "__main__":
    import json
    deck = json.loads(Path("deck.json").read_text(encoding="utf-8"))
    output_dir = r"/output_ppt"
    output_file = deck.get("title", "untitled") + "_output.pptx"
    output_path = os.path.join(output_dir, output_file)
    out = render_deck(deck,output_path)
    print("saved:", out)
    import json, collections


    deck = json.load(open("deck.json", "r", encoding="utf-8"))
    cnt = collections.Counter([s.get("template_id") for s in deck["slides"]])
    print(cnt)

