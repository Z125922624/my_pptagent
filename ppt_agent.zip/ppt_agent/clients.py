# clients.py
import os
from dotenv import load_dotenv
from openai import AsyncOpenAI, OpenAI

def load_env(env_path: str = "env_template.env") -> None:
    load_dotenv(env_path)

def disable_proxy_env() -> None:
    for k in ["HTTP_PROXY","HTTPS_PROXY","http_proxy","https_proxy"]:
        os.environ.pop(k, None)

def get_deepseek_async_client() -> AsyncOpenAI:
    # DeepSeek 使用 OpenAI SDK 兼容接口
    api_key = os.environ.get("DEEPSEEK_API_KEY")
    if not api_key:
        raise RuntimeError("DEEPSEEK_API_KEY 未设置")
    return AsyncOpenAI(api_key=api_key, base_url="https://api.deepseek.com")

def get_deepseek_client() -> OpenAI:
    api_key = os.environ.get("DEEPSEEK_API_KEY")
    if not api_key:
        raise RuntimeError("DEEPSEEK_API_KEY 未设置")
    return OpenAI(api_key=api_key, base_url="https://api.deepseek.com")
