# write_one_slide.py
from __future__ import annotations

import asyncio
import json
import re
from typing import Any, Dict, List, Optional

# 你项目里已有 get_deepseek_async_client()，这里假设 client.chat.completions.create 可用
# 如果你 client 的接口不同，把 _chat_json 内部那段替换掉即可。


def _safe_json_load(s: str) -> Optional[dict]:
    if not s:
        return None
    # 尝试提取 JSON 段
    m = re.search(r"\{.*\}", s, flags=re.S)
    if m:
        s = m.group(0)
    try:
        return json.loads(s)
    except Exception:
        return None


def _take_sources_from_evidence(pack: Dict[str, Any]) -> List[str]:
    ev = (pack.get("evidence") or {})
    texts = ev.get("text_snippets") or []
    srcs = []
    for t in texts:
        p = t.get("source")
        if p:
            srcs.append(p)
    # 去重
    out = []
    for x in srcs:
        if x not in out:
            out.append(x)
    return out[:3]


def _pick_image_from_pack(pack: Dict[str, Any]) -> Optional[Dict[str, str]]:
    ev = (pack.get("evidence") or {})
    hits = ev.get("image_hits") or []
    if not hits:
        return None
    h = hits[0] or {}
    path = h.get("image_path") or ""
    cap = h.get("caption") or ""
    if not path:
        return None
    return {"path": path, "caption": cap}


def _fallback_slide(brief: Dict[str, Any], pack: Dict[str, Any]) -> Dict[str, Any]:
    """LLM 失败时的兜底：依然输出咨询风结构。"""
    title = pack.get("slide_title") or ""
    takeaway = pack.get("takeaway") or ""
    slide_no = int(pack.get("slide_no") or 0)

    cards = [
        {"title": "关键点 1", "bullets": [takeaway or "用一句话说明本页结论"]},
        {"title": "关键点 2", "bullets": ["补充一个影响/价值点", "补充一个场景/对象"]},
        {"title": "关键点 3", "bullets": ["补充一个做法/机制", "补充一个约束/条件"]},
    ]

    fact = {
        "label": "要点提醒",
        "value": "缺少证据时避免硬编数据",
        "note": "可在检索补齐数据后替换为量化指标"
    }

    example = {
        "title": "例子",
        "text": f"例如：在{brief.get('topic','该主题')}的典型场景中，本页结论如何落地。"
    }

    blocks = [
        {"kind": "callout", "content": takeaway or "本页结论：用一句话讲清楚价值。", "meta": {}},
        {"kind": "cards", "content": cards, "meta": {}},
        {"kind": "fact", "content": fact, "meta": {}},
        {"kind": "example", "content": example, "meta": {}},
    ]

    img = _pick_image_from_pack(pack)
    if img:
        blocks.append({"kind": "image", "content": img, "meta": {}})

    return {
        "slide_no": slide_no,
        "slide_type": "content",
        "title": title or f"Slide {slide_no}",
        "layout_hint": "consulting",
        "template_id": None,
        "blocks": blocks,
        "speaker_notes": "",
        "citations": _take_sources_from_evidence(pack),
    }


async def _chat_json(client, model: str, system_prompt: str, user_prompt: str, temperature: float = 0.2) -> Optional[dict]:
    """
    你项目里的 deepseek async client 只要能兼容 chat.completions.create 即可。
    """
    resp = await client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        temperature=temperature,
        timeout=120,
    )
    text = (resp.choices[0].message.content or "").strip()
    return _safe_json_load(text)

import asyncio
import json
import random
from typing import Dict, Any, List, Optional, Tuple

# 你项目里已有的依赖（保持不动）
# from your_pkg.schema import SlideSpec, DeckSpec, Block
# from your_pkg.llm import get_deepseek_async_client, _chat_json
# from your_pkg.fallback import _fallback_slide, _take_sources_from_evidence, _pick_image_from_pack

# ----------------------------
# 小工具：从 blocks 里找某 kind
# ----------------------------
def _get_block(blocks: List[Dict[str, Any]], kind: str) -> Optional[Dict[str, Any]]:
    for b in blocks or []:
        if (b.get("kind") or "").strip() == kind:
            return b
    return None


# ----------------------------
# cards 规范化：title + text（兼容 bullets->text）
# ----------------------------
def _normalize_cards_content(cards: Any) -> List[Dict[str, str]]:
    out: List[Dict[str, str]] = []
    if not isinstance(cards, list):
        return out

    for c in cards:
        if not isinstance(c, dict):
            continue
        title = (c.get("title") or "").strip()
        text = (c.get("text") or "").strip()

        # 兼容旧结构 bullets: ["a","b"] -> text: "• a\n• b"
        bullets = c.get("bullets")
        if (not text) and isinstance(bullets, list):
            bs = [str(x).strip() for x in bullets if str(x).strip()]
            if bs:
                text = "\n".join([f"• {x}" for x in bs[:3]])

        if title or text:
            out.append({"title": title[:26], "text": text[:120]})
    return out


# ----------------------------
# slide dict 规范化：layout_hint、blocks 结构修复
# ----------------------------
def _normalize_slide_dict(data: Dict[str, Any], pack: Dict[str, Any]) -> Dict[str, Any]:
    # layout_hint 只能是 cards/process/bullets
    lh = (data.get("layout_hint") or "").strip().lower()
    if lh not in ("cards", "process", "bullets"):
        # 咨询风默认 cards
        data["layout_hint"] = "cards"
    else:
        data["layout_hint"] = lh

    # template_id 大写化
    tid = (data.get("template_id") or "").strip().upper()
    if tid not in ("A", "B", "C"):
        data["template_id"] = None
    else:
        data["template_id"] = tid

    # blocks 必须是 list[dict]
    blocks = data.get("blocks")
    if not isinstance(blocks, list):
        blocks = []
    # 修 cards block
    for b in blocks:
        if not isinstance(b, dict):
            continue
        if b.get("kind") == "cards":
            b["content"] = _normalize_cards_content(b.get("content"))
        if b.get("kind") == "bullets" and not isinstance(b.get("content"), list):
            # bullets 必须 list[str]
            txt = b.get("content")
            if isinstance(txt, str) and txt.strip():
                b["content"] = [txt.strip()]
            else:
                b["content"] = []

    data["blocks"] = blocks

    # citations 兜底
    if "citations" not in data or not isinstance(data["citations"], list):
        data["citations"] = _take_sources_from_evidence(pack)

    # 如果模型没给 image，但检索里有候选，就补第一张（你已有函数）
    has_image = any(isinstance(b, dict) and b.get("kind") == "image" for b in (data.get("blocks") or []))
    if not has_image:
        img = _pick_image_from_pack(pack)
        if img:
            data["blocks"].append({"kind": "image", "content": img, "meta": {}})

    return data


# ----------------------------
# 模板选择：按内容倾向打分（单页）
# ----------------------------
def _template_prefer_by_content(slide_dict: Dict[str, Any]) -> str:
    blocks = slide_dict.get("blocks", []) or []
    cards_block = _get_block(blocks, "cards")
    fact_block = _get_block(blocks, "fact")
    process_block = _get_block(blocks, "process")

    cards = (cards_block or {}).get("content") or []
    cards_n = len(cards) if isinstance(cards, list) else 0
    has_fact = bool((fact_block or {}).get("content"))
    has_process = bool((process_block or {}).get("content"))

    # 规则偏好（你可以继续调整）
    if cards_n < 3:
        return "B"
    if cards_n == 3:
        return "C"
    if has_fact:
        return "C"
    if has_process:
        return "A"



    # 默认
    return random.choice(["A", "B", "C"])


# ----------------------------
# 模板后处理：保证 A/B/C 都出现、尽量均匀、相邻不重复
# （并发写每页时必须靠这个保证）
# ----------------------------
def _post_assign_template_ids(slide_dicts: List[Dict[str, Any]]) -> None:
    if not slide_dicts:
        return

    # 1) 先拿模型建议，否则按内容偏好
    for s in slide_dicts:
        tid = (s.get("template_id") or "").strip().upper()
        if tid not in ("A", "B", "C"):
            s["template_id"] = _template_prefer_by_content(s)
        else:
            s["template_id"] = tid

    # 2) 相邻不重复（简单修正）
    for i in range(1, len(slide_dicts)):
        if slide_dicts[i]["template_id"] == slide_dicts[i - 1]["template_id"]:
            # 换成另外两个里更合适的一个
            cur = slide_dicts[i]["template_id"]
            candidates = [t for t in ("A", "B", "C") if t != cur]
            # 用 slide_no 固定随机，避免每次运行变
            seed = int(slide_dicts[i].get("slide_no") or i)
            r = random.Random(seed)
            slide_dicts[i]["template_id"] = r.choice(candidates)

    # 3) 确保 A/B/C 都出现
    present = {s["template_id"] for s in slide_dicts}
    missing = [t for t in ("A", "B", "C") if t not in present]
    if missing:
        # 把一些“最不敏感”的页替换成缺失模板
        # 优先替换：cards少/无process/无fact 的页
        def replace_score(s: Dict[str, Any]) -> int:
            pref = _template_prefer_by_content(s)
            return 0 if pref == "A" else 1

        candidates = sorted(slide_dicts, key=replace_score)
        mi = 0
        for s in candidates:
            if mi >= len(missing):
                break
            # 避免制造相邻重复
            idx = slide_dicts.index(s)
            new_tid = missing[mi]
            left_tid = slide_dicts[idx - 1]["template_id"] if idx - 1 >= 0 else None
            right_tid = slide_dicts[idx + 1]["template_id"] if idx + 1 < len(slide_dicts) else None
            if new_tid != left_tid and new_tid != right_tid:
                s["template_id"] = new_tid
                mi += 1

    # 4) 轻度均匀（可选）：如果某个模板过多，把一部分换成少的
    counts = {t: 0 for t in ("A", "B", "C")}
    for s in slide_dicts:
        counts[s["template_id"]] += 1

    # 允许的最大差值
    max_diff = 2
    # 贪心拉平
    for _ in range(20):
        hi = max(counts, key=lambda k: counts[k])
        lo = min(counts, key=lambda k: counts[k])
        if counts[hi] - counts[lo] <= max_diff:
            break
        # 找一个 hi 的 slide 尝试换成 lo，且不相邻重复
        moved = False
        for i, s in enumerate(slide_dicts):
            if s["template_id"] != hi:
                continue
            left_tid = slide_dicts[i - 1]["template_id"] if i - 1 >= 0 else None
            right_tid = slide_dicts[i + 1]["template_id"] if i + 1 < len(slide_dicts) else None
            if lo != left_tid and lo != right_tid:
                s["template_id"] = lo
                counts[hi] -= 1
                counts[lo] += 1
                moved = True
                break
        if not moved:
            break


# ============================================================
# ✅ 替换版 write_one_slide：输出严格 JSON，匹配你 Pydantic
# ============================================================
async def write_one_slide(client, brief: Dict[str, Any], style_guide: Dict[str, Any], pack: Dict[str, Any], sem: asyncio.Semaphore) -> Dict[str, Any]:
    async with sem:
        topic = brief.get("topic", "")
        audience = brief.get("audience", "general")
        tone = brief.get("tone", "professional")

        slide_no = int(pack.get("slide_no") or 0)
        slide_title = pack.get("slide_title") or f"Slide {slide_no}"
        takeaway = pack.get("takeaway") or ""
        ev = pack.get("evidence") or {}
        text_snips = ev.get("text_snippets") or []
        img_hits = ev.get("image_hits") or []
        template_id= pack.get("template_id","") or random.choice(["A", "B", "C"])

        snippets = []
        for t in text_snips[:3]:
            snippets.append({
                "source": t.get("source", ""),
                "content": (t.get("content", "")[:380]).strip()
            })

        image_candidates = []
        for h in img_hits[:]:
            image_candidates.append({
                "image_path": h.get("image_path", ""),
                "caption": h.get("caption", ""),
                "score": h.get("score", 0.0),
                "source": h.get("source", ""),
            })

        # ⚠️ 关键：不要再让模型输出 layout_hint=consulting
        # ⚠️ cards 必须 title+text（text 里用 • 换行）
        system_prompt = f"""
        你是资深咨询顾问（McKinsey/BCG风格）与PPT撰稿人。请输出**严格 JSON**（不要 markdown、不要解释）。
        语言：{style_guide.get("language", "zh")}；语气：{tone}；受众：{audience}。
        目标：强结论、信息密度高、少而精、MECE 分组。

        必须遵守（强约束）：
        - 顶层字段必须包含：slide_no, slide_type, title, layout_hint, template_id, blocks, speaker_notes, citations
        - layout_hint 只能是 "cards" 或 "process" 或 "bullets"（默认用 "cards"）
        - template_id 必须是 "A" 或 "B" 或 "C"（不要输出 null）
        - callout：一句强结论（<=22字，结论+价值）
        封面页特例（强约束）：
        - 若 slide_no == 1 或 slide_type == "title"：
          - blocks 必须包含且仅包含 1 个 cards block
          - cards.content 必须 **恰好 4 张卡片**（必须输出满 4 张，不能少）
          - 4 张卡片必须覆盖 4 个不同维度（不要重复：定义/特征/场景/趋势 或 定义/组成/应用/趋势 等）
          - 每张卡片：title <= 12字；2~3条 bullet；每条 bullet <= 16字
          封面页推荐 4 卡维度（优先按此组织）：
            1) 核心定义（是什么）
            2) 关键特征（有什么能力）
            3) 典型场景（用在哪）
            4) 发展趋势（往哪去）
            


        - cards：2~4张卡片（MECE分组）
          - 每张卡片必须是 {{ "title": "...", "text": "• ...\\n• ..." }}
          - title <= 12字；每条 bullet <= 16字；最多3条 bullet
        - fact：给出“可校验/保守”的信息，避免硬编
          - {{ "label": "...", "value": "...", "note": "...", "source": "..." }}
        - example：1个落地例子，1~2句
          - {{ "title": "...", "text": "..." }}
          若 template_id == "C"：
        - example.text 用作对 callout 的“补充解释/洞察”（1~2句，<=40字），不要写成具体案例也可以
        - fact 保持可校验

          

        图片规则（强约束）：
        - image：不要输出（由程序根据 image_candidates 自动填充；禁止编造 path）
        - blocks 中禁止出现 kind="image"，如出现视为格式错误

        输出格式示例（仅示意结构，不要照抄文案）：
        {{
          "slide_no": 1,
          "slide_type": "content",
          "title": "标题",
          "layout_hint": "cards",
          "template_id": "A",
          "blocks": [
            {{ "kind": "callout", "content": "一句强结论" }},
            {{ "kind": "cards", "content": [
              {{ "title": "维度A", "text": "• 要点1\\n• 要点2" }},
              {{ "title": "维度B", "text": "• 要点1\\n• 要点2" }}
            ] }},
            {{ "kind": "fact", "content": {{ "label": "指标", "value": "区间/趋势", "note": "证据不足则保守表述", "source": "来自evidence的source" }} }},
            {{ "kind": "example", "content": {{ "title": "例子", "text": "1~2句可落地描述" }} }}
          ],
          "speaker_notes": "讲解要点（2~4句）",
          "citations": ["来自evidence的source（1~3条）"]
        }}

        c itations：优先从 evidence sources 里挑 1~3 个

        模板建议（仅按本页内容判断，不要考虑全局均匀）：
        A：2x2 cards 为主（框架拆解/对比维度）
        B：流程/阶段（更适合 process 或 3段路径）
        C：事实/洞察强调（fact 更突出 + 1~2张 cards）
        """

        user_prompt = json.dumps({
            "slide_no": slide_no,
            "slide_title": slide_title,
            "takeaway": takeaway,
            "topic": topic,
            "evidence_snippets": snippets,
            "image_candidates": image_candidates,
            "required_output_example": {
                "slide_no": slide_no,
                "slide_type": "content",
                "title": slide_title,
                "layout_hint": "cards",
                "template_id": template_id,
                "blocks": [
                    {"kind": "callout", "content": "一句强结论"},
                    {"kind": "cards", "content": [
                        {"title": "维度A", "text": "• 要点1\\n• 要点2"},
                        {"title": "维度B", "text": "• 要点1\\n• 要点2"}
                    ]},
                    {"kind": "fact", "content": {"label": "指标", "value": "区间/趋势", "note": "证据不足则保守表述", "source": "来自evidence的source"}},
                    {"kind": "example", "content": {"title": "例子", "text": "1~2句可落地描述"}},
                    {"kind": "image", "content": {"path": "kb/images/xxx.png", "caption": "图注"}}
                ],
                "speaker_notes": "可写扩展解释",
                "citations": ["D:\\path\\to\\doc.md"]
            }
        }, ensure_ascii=False)

        try:
            data = await _chat_json(
                client=client,
                model=style_guide.get("model", "deepseek-chat"),
                system_prompt=system_prompt.strip(),
                user_prompt=user_prompt,
                temperature=0.2,
            )

            if not isinstance(data, dict):
                return _fallback_slide(brief, pack)

            # 兜底补字段（注意 layout_hint）
            data.setdefault("slide_no", slide_no)
            data.setdefault("slide_type", "content")
            data.setdefault("title", slide_title)
            if (data.get("layout_hint") or "").strip().lower() not in ("cards", "process", "bullets"):
                data["layout_hint"] = "cards"
            # template_id 兜底（先给 A，后面会统一后处理）
            tid = (data.get("template_id") or "").strip().upper()
            data["template_id"] = tid if tid in ("A", "B", "C") else "A"

            data.setdefault("blocks", [])
            data.setdefault("speaker_notes", "")
            if "citations" not in data or not isinstance(data["citations"], list):
                data["citations"] = _take_sources_from_evidence(pack)

            # 规范化 cards/bullets 等结构 + 补图
            data = _normalize_slide_dict(data, pack)

            return data

        except Exception:
            return _fallback_slide(brief, pack)


