from pathlib import Path
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings

STORE_DIR = r"D:\mypptAgent\kb_store"

embeddings = HuggingFaceEmbeddings(model_name="BAAI/bge-small-zh-v1.5")
vs = FAISS.load_local(
    str(STORE_DIR),
    embeddings,
    allow_dangerous_deserialization=True,  # 允许加载 index.pkl
)

# docstore 里存的就是切好的 Document
doc_dict = vs.docstore._dict  # {doc_id: Document}
print("total chunks:", len(doc_dict))

# 打印前 10 个
for i, (doc_id, doc) in enumerate(list(doc_dict.items())[10:50], start=1):
    print(f"\n=== Chunk {i} ===")
    print("doc_id:", doc_id)
    print("metadata:", doc.metadata)
    print("text:", doc.page_content[:])
