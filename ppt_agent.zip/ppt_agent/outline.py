# ========== 4) Step 2: 生成大纲 Outline ==========
import json
from typing import List

from pydantic import ValidationError

from ppt_agent.Briefspec import step1_parse_brief, chat_json, get_deepseek_client
from ppt_agent.models import OutlineItem, BriefSpec
from kb import kb_retrieve

def step2_plan_outline(brief: BriefSpec, model: str = "deepseek-chat") -> List[OutlineItem]:
    client = get_deepseek_client()

    system_prompt = """
你是PPT大纲规划器。请基于 BriefSpec 生成一个 JSON（json_object），结构如下：
{
  "outline": [
    {"slide_title": string, "takeaway": string, "needs_research": boolean}
  ]
}

规则：
- outline 数量必须等于 brief.slide_count
- 每页 slide_title 简短（<=14字更好）
- takeaway 用一句话说明“这页让观众记住什么”
- needs_research: 只有当该页需要具体数据/引用/竞品/政策/新闻时才为 true
只输出 JSON，不要输出额外文字。
"""

    user_prompt = f"""
BriefSpec(json):
{brief.model_dump_json(ensure_ascii=False)}
请输出上述结构的 json。
"""

    data = chat_json(client, model=model, system_prompt=system_prompt, user_prompt=user_prompt, max_tokens=2000)

    outline_raw = data.get("outline", [])
    try:
        outline = [OutlineItem.model_validate(x) for x in outline_raw]
    except ValidationError as e:
        raise RuntimeError(f"OutlineItem 校验失败：{e}\n原始返回：{data}")

    if len(outline) != brief.slide_count:
        raise RuntimeError(f"大纲页数不匹配：期望 {brief.slide_count}，实际 {len(outline)}")

    return outline


# ========== 5) Demo ==========
if __name__ == "__main__":
    user_input = "生成一个关于共享单车为主题的PPT，面向非技术同事，8页，偏科普但要专业。"
    brief = step1_parse_brief(user_input)
    outline = step2_plan_outline(brief)
    out=kb_retrieve.retrieve_for_outline(brief, outline)

    print(json.dumps(out, ensure_ascii=False, indent=2))



    print("=== Step1 BriefSpec ===")
    print(brief.model_dump_json(ensure_ascii=False, indent=2))

    print("\n=== Step2 Outline ===")
    print(json.dumps([o.model_dump() for o in outline], ensure_ascii=False, indent=2))