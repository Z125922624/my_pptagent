import asyncio
import os
from pathlib import Path

from outline import step2_plan_outline
from ppt_agent.Briefspec import step1_parse_brief
from kb import kb_retrieve
from render_pptx import render_deck
from write_deck_parallel import write_deck_parallel

def pretty(obj):
    return json.dumps(obj, ensure_ascii=False, indent=2)

if __name__ == "__main__":
    user_input = "生成一个关于机器人为主题的PPT，面向非技术同事，9页，偏科普但要专业。"

    # Step1
    brief = step1_parse_brief(user_input)
    print("=== Step1 BriefSpec (Pydantic) ===")
    print(brief.model_dump_json(ensure_ascii=False, indent=2))

    # Step2
    outline_items = step2_plan_outline(brief)
    print("\n=== Step2 OutlineItems (list[Pydantic]) ===")
    print(pretty([o.model_dump() for o in outline_items]))

    # Step3
    evidence_packs = kb_retrieve.retrieve_for_outline(brief, outline_items, ensure_image=False)
    print("\n=== Step3 Evidence Packs (list[dict]) ===")
    print(pretty(evidence_packs))

    # Step4
    deck_spec = asyncio.run(write_deck_parallel(brief, outline_items, evidence_packs, concurrency=4))
    print("\n=== Step4 DeckSpec (Pydantic) ===")
    print(deck_spec.model_dump_json(ensure_ascii=False, indent=2))

    # 保存 JSON（可选）
    deck_dict = deck_spec.model_dump()
    Path("deck.json").write_text(pretty(deck_dict), encoding="utf-8")
    import json

    deck = json.loads(Path("deck.json").read_text(encoding="utf-8"))
    output_dir = r"/output_ppt"
    output_file = deck.get("title", "untitled") + "_output.pptx"
    output_path = os.path.join(output_dir, output_file)
    out = render_deck(deck,output_path)
    print("\nSaved deck.json")

