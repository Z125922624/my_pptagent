# kb_retrieve.py
import os
import json
import hashlib
import time
from pathlib import Path
from typing import Any, Optional, List, Dict, Tuple

import requests
from requests.exceptions import ChunkedEncodingError, ConnectionError, Timeout, RequestException

from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from volcenginesdkarkruntime import Ark

# ===== 路径配置 =====
PROJECT_ROOT = Path(__file__).resolve().parent.parent  # D:\mypptAgent
STORE_DIR = PROJECT_ROOT / "kb_store"

IMAGES_DIR = PROJECT_ROOT / "kb" / "images"
IMAGES_JSON = IMAGES_DIR / "images.json"

ARK_BASE_URL = "https://ark.cn-beijing.volces.com/api/v3"
SEEDREAM_MODEL = "doubao-seedream-4-5-251128"


def load_vs():
    embeddings = HuggingFaceEmbeddings(model_name="BAAI/bge-small-zh-v1.5")
    return FAISS.load_local(str(STORE_DIR), embeddings, allow_dangerous_deserialization=True)


def _get(o: Any, key: str, default=None):
    if isinstance(o, dict):
        return o.get(key, default)
    return getattr(o, key, default)


# ========== Seedream 图片兜底相关 ==========
def _disable_proxy_env():
    for k in ["HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy"]:
        os.environ.pop(k, None)


def _load_images_json() -> list:
    if not IMAGES_JSON.exists():
        IMAGES_JSON.parent.mkdir(parents=True, exist_ok=True)
        IMAGES_JSON.write_text("[]", encoding="utf-8")
        return []
    return json.loads(IMAGES_JSON.read_text(encoding="utf-8"))


def _append_images_json(path_str: str, caption: str, url: Optional[str] = None) -> None:
    items = _load_images_json()
    if any(it.get("path") == path_str for it in items):
        return
    entry = {"path": path_str, "caption": caption}
    if url:
        entry["url"] = url
    items.append(entry)
    IMAGES_JSON.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")


def _download_image(url: str, out_file: Path, timeout: int = 120, retries: int = 3) -> None:
    """
    ✅ 增加重试：解决 ChunkedEncodingError / 网络抖动
    """
    last_err = None
    for attempt in range(1, retries + 1):
        try:
            r = requests.get(url, timeout=timeout)
            r.raise_for_status()
            out_file.parent.mkdir(parents=True, exist_ok=True)
            out_file.write_bytes(r.content)
            return
        except (ChunkedEncodingError, ConnectionError, Timeout, RequestException) as e:
            last_err = e
            # 简单退避
            time.sleep(0.8 * attempt)
    raise last_err if last_err else RuntimeError("download failed")


def _build_seedream_prompt(topic: str, slide_title: str, takeaway: str) -> str:
    return (
        f"主题：{topic}。\n"
        f"页面标题：{slide_title}。\n"
        f"要表达的内容：{takeaway}。\n"
        "生成一张现代商务PPT配图，要求适合ppt配图，美观正式，16:9横版，干净留白。\n"
        "画面元素与页面内容匹配。\n"
        "不要出现任何文字，不要出现品牌logo，不要水印。"
    )


def _make_unique_filename(topic: str, slide_no: int, slide_title: str) -> str:
    salt = str(time.time_ns())
    raw = f"{topic}|{slide_no}|{slide_title}|{salt}"
    h = hashlib.md5(raw.encode("utf-8")).hexdigest()[:10]
    return f"gen_{slide_no:02d}_{h}.png"


def seedream_generate_and_save(topic: str, slide_no: int, slide_title: str, takeaway: str) -> dict:
    """
    调 Seedream 生成图片，下载到 kb/images/ 下，
    并写入 kb/images/images.json
    """
    _disable_proxy_env()

    # ✅ 兼容你之前拼错的 SEEDREAN_API_KEY
    api_key = os.environ.get("SEEDREAM_API_KEY") or os.environ.get("SEEDREAN_API_KEY")
    if not api_key:
        raise RuntimeError("SEEDREAM_API_KEY 未设置，无法调用 Seedream 生成图片")

    client = Ark(base_url=ARK_BASE_URL, api_key=api_key)

    prompt = _build_seedream_prompt(topic, slide_title, takeaway)

    filename = _make_unique_filename(topic, slide_no, slide_title)
    local_file = IMAGES_DIR / filename

    resp = client.images.generate(
        model=SEEDREAM_MODEL,
        prompt=prompt,
        size="2K",
        response_format="url",
        watermark=False,
    )
    url = resp.data[0].url
    _download_image(url, local_file)

    rel_path = f"kb/images/{filename}"
    caption = f"{topic}｜{slide_title}｜生成示意图（关键词：{takeaway}）"

    _append_images_json(rel_path, caption, url=url)
    print("调用API生产图片")

    return {
        "image_path": rel_path,
        "caption": caption,
        "score": 0.0,
        "source": "seedream",
    }


# ========== 图片选择策略（阈值 + 去重 + score 方向） ==========
def _pick_best_image(
    image_hits: List[Dict[str, Any]],
    used_images: set,
    *,
    score_threshold: float,
    score_is_distance: bool,
) -> Optional[Dict[str, Any]]:
    """
    从检索结果里选“未使用且达阈值”的最优图片。
    - score_is_distance=True：score 越小越好（FAISS 距离）；要求 score <= threshold
    - score_is_distance=False：score 越大越好（相似度）；要求 score >= threshold
    """
    candidates: List[Tuple[float, Dict[str, Any]]] = []
    for h in (image_hits or []):
        p = (h.get("image_path") or h.get("path") or "").strip()
        if not p:
            continue
        if p in used_images:
            continue

        s = h.get("score", None)
        try:
            s = float(s) if s is not None else None
        except Exception:
            s = None
        if s is None:
            continue

        if score_is_distance:
            if s > score_threshold:
                continue
        else:
            if s < score_threshold:
                continue

        candidates.append((s, h))

    if not candidates:
        return None

    # 距离模式：越小越好；相似度模式：越大越好
    candidates.sort(key=lambda x: x[0], reverse=(not score_is_distance))
    return candidates[0][1]


# ========== 检索 ==========
def retrieve_for_slide(
    vs,
    topic: str,
    slide_no: int,
    slide_title: str,
    takeaway: str,
    k: int = 10,
    ensure_image: bool = True,
    used_images: Optional[set] = None,
    # ✅ 新增：阈值与方向
    image_score_threshold: float = 0.55,
    score_is_distance: bool = True,
) -> dict:
    """
    ✅ 统一在这里做：
    - image 去重（跨页）
    - image 阈值过滤（低分不采用）
    - 不达标/已用 -> 直接生成并保存，并写入 images.json
    - 返回时 image_hits[0] 一定是“本页最终选定图”
    """
    used_images = used_images if used_images is not None else set()

    query = f"{topic}；{slide_title}；{takeaway}"
    docs_scores = vs.similarity_search_with_score(query, k=k)

    text_snippets = []
    image_hits_all = []

    for d, score in docs_scores:
        meta = d.metadata or {}
        doc_type = meta.get("doc_type") or meta.get("type") or "text"

        if doc_type == "image":
            image_path = meta.get("image_path") or meta.get("source") or ""
            image_hits_all.append({
                "image_path": image_path,
                "caption": d.page_content,
                "score": float(score),
                "source": meta.get("source", ""),
            })
        else:
            text_snippets.append({
                "content": d.page_content,
                "score": float(score),
                "source": meta.get("source", ""),
                "page": meta.get("page", None),
                "chunk_id": meta.get("chunk_id", ""),
                "doc_type": doc_type,
            })

    final_image_hit: Optional[Dict[str, Any]] = None

    # 1) 先尝试用检索图（未用过且达阈值）
    best = _pick_best_image(
        image_hits_all,
        used_images,
        score_threshold=image_score_threshold,
        score_is_distance=score_is_distance,
    )
    if best:
        final_image_hit = best

    # 2) 不达标 or 已用 or 没图：生成
    if ensure_image and not final_image_hit:
        try:
            gen = seedream_generate_and_save(topic, int(slide_no), slide_title, takeaway)
            final_image_hit = gen
        except Exception as e:
            final_image_hit = {
                "image_path": "",
                "caption": f"（未生成图片：{type(e).__name__}）",
                "score": 0.0,
                "source": "seedream_error",
            }

    # 3) 更新 used_images（只有成功有路径才登记）
    if final_image_hit:
        p0 = (final_image_hit.get("image_path") or "").strip()
        if p0:
            used_images.add(p0)

    # 4) 返回：保证 image_hits[0] 是最终选定；后面再给一点候选（不含已用）
    #    （注意：这些候选不再做阈值过滤也可以；你想严格一点也可以继续过滤）
    # 4) 返回：保证 image_hits[0] 是最终选定；后面再给 1 个备用
    rest = []
    for h in image_hits_all:
        p = (h.get("image_path") or "").strip()
        if not p:
            continue
        if final_image_hit and p == (final_image_hit.get("image_path") or "").strip():
            continue
        if p in used_images:
            continue
        rest.append(h)

    image_hits_out = []
    if final_image_hit:
        image_hits_out.append(final_image_hit)

    # ✅ 先塞一个检索备用
    if rest:
        image_hits_out.append(rest[0])
        p1 = (rest[0].get("image_path") or "").strip()
        if p1:
            used_images.add(p1)

    # ✅ 再兜底：如果还不到 2 张，就生成“备用图”
    #    这样 B/C 模板渲染时一定有两张（除非生成也失败）
    while ensure_image and len(image_hits_out) < 2:
        try:
            alt_takeaway = f"{takeaway}（备用角度）"
            gen2 = seedream_generate_and_save(topic, int(slide_no), slide_title, alt_takeaway)
            p2 = (gen2.get("image_path") or "").strip()

            # 极端情况下生成重复（很少），重复就再试一次
            if p2 and p2 in used_images:
                # 重新生成一次
                alt_takeaway = f"{takeaway}（备用角度2）"
                gen2 = seedream_generate_and_save(topic, int(slide_no), slide_title, alt_takeaway)
                p2 = (gen2.get("image_path") or "").strip()

            image_hits_out.append(gen2)
            if p2:
                used_images.add(p2)
        except Exception as e:
            image_hits_out.append({
                "image_path": "",
                "caption": f"（未生成备用图：{type(e).__name__}）",
                "score": 0.0,
                "source": "seedream_error",
            })
            break

    return {
    "query": query,
    "text_snippets": text_snippets[:4],
    "image_hits": image_hits_out[:2],  # ✅ 固定最多返回 2 张
    }


def retrieve_for_outline(
    brief: Any,
    outline: list[Any],
    ensure_image: bool = True,
    # ✅ 新增：全局阈值配置
    image_score_threshold: float = 0.35,
    score_is_distance: bool = True,
) -> list[dict]:
    vs = load_vs()
    topic = brief["topic"] if isinstance(brief, dict) else getattr(brief, "topic", "")

    used_images: set = set()  # ✅ 本次生成 PPT 生命周期内不重复

    packs = []
    for i, o in enumerate(outline, start=1):
        slide_title = _get(o, "slide_title", "")
        takeaway = _get(o, "takeaway", "")
        needs_research = _get(o, "needs_research", False)

        k = 4

        packs.append({
            "slide_no": i,
            "slide_title": slide_title,
            "takeaway": takeaway,
            "needs_research": needs_research,
            "evidence": retrieve_for_slide(
                vs,
                topic=topic,
                slide_no=i,
                slide_title=slide_title,
                takeaway=takeaway,
                k=k,
                ensure_image=ensure_image,
                used_images=used_images,
                image_score_threshold=image_score_threshold,
                score_is_distance=score_is_distance,
            ),
        })
    return packs
