# models.py
from __future__ import annotations

from pydantic import BaseModel, Field
from typing import List, Literal, Optional, Dict, Any, Union

SlideType = Literal["title", "agenda", "section", "content", "two_col", "comparison", "closing"]
BlockKind = Literal[
    "title", "callout", "bullets", "text", "image", "chart", "table", "quote",
    "cards", "process", "fact", "example"
]

LayoutHint = Literal["cards", "process", "bullets"]


class BriefSpec(BaseModel):
    topic: str
    audience: str = "general"
    goal: str = "inform"
    language: str = "zh"
    slide_count: int = 10
    tone: str = "professional"
    must_include: List[str] = Field(default_factory=list)
    must_avoid: List[str] = Field(default_factory=list)
    template_name: str = "business_clean"


class OutlineItem(BaseModel):
    slide_title: str
    takeaway: str
    needs_research: bool = False


# ===== Block content schemas =====
class ImageContent(BaseModel):
    path: str
    caption: Optional[str] = None


class CardItem(BaseModel):
    title: str
    text: str


BlockContent = Union[
    str,
    List[str],                 # bullets / process
    ImageContent,              # image
    List[CardItem],            # cards
    Dict[str, Any],            # chart/table/其他扩展
]


class Block(BaseModel):
    kind: BlockKind
    content: BlockContent
    meta: Dict[str, Any] = Field(default_factory=dict)


class SlideSpec(BaseModel):
    slide_no: Optional[int] = None
    slide_type: SlideType = "content"
    title: str
    layout_hint: Optional[LayoutHint] = None
    template_id: Optional[str] = None

    blocks: List[Block] = Field(default_factory=list)
    speaker_notes: Optional[str] = None
    citations: List[str] = Field(default_factory=list)


class DeckSpec(BaseModel):
    title: str
    subtitle: Optional[str] = None
    slides: List[SlideSpec]
