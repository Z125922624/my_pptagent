import os
import json
from typing import List

from dotenv import load_dotenv
from pydantic import BaseModel, Field, ValidationError
from openai import OpenAI

from models import BriefSpec

load_dotenv("env_template.env")
# ========== 2) DeepSeek Client（OpenAI兼容） ==========
def get_deepseek_client() -> OpenAI:
    api_key = os.environ.get("DEEPSEEK_API_KEY")
    if not api_key:
        raise RuntimeError("Missing DEEPSEEK_API_KEY env var")

    return OpenAI(api_key=api_key, base_url="https://api.deepseek.com")


def chat_json(client: OpenAI, model: str, system_prompt: str, user_prompt: str, max_tokens: int = 1200) -> dict:
    """
    强制模型输出 JSON：response_format={'type':'json_object'}
    注意：prompt 里必须明确要求 JSON（包含 'json'），避免输出空白或跑偏。
    """
    resp = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        response_format={"type": "json_object"},
        max_tokens=max_tokens,
        temperature=0.2,  # deepseek-chat 支持；若用 deepseek-reasoner 需注意其参数限制
    )
    content = resp.choices[0].message.content or "{}"
    return json.loads(content)
# ========== 3) Step 1: 解析 Brief ==========
def step1_parse_brief(user_input: str, model: str = "deepseek-chat") -> BriefSpec:
    client = get_deepseek_client()

    system_prompt = """
你是一个PPT需求解析器。请把用户输入解析为 JSON（json_object）并严格匹配下面字段。
只输出 JSON，不要输出任何额外文字。

JSON字段:
{
  "topic": string,
  "audience": string,
  "goal": string,
  "language": "zh" | "en",
  "slide_count": integer,
  "tone": string,
  "must_include": string[],
  "must_avoid": string[],
  "template_name": string
}

要求：
- 如果用户没给页数：slide_count=8
- language 默认 "zh"
- template_name 默认 "business_clean"
"""
    user_prompt = f"用户需求：{user_input}\n请输出符合 schema 的 json。"

    data = chat_json(client, model=model, system_prompt=system_prompt, user_prompt=user_prompt)
    try:
        return BriefSpec.model_validate(data)
    except ValidationError as e:
        raise RuntimeError(f"BriefSpec 校验失败：{e}\n原始返回：{data}")