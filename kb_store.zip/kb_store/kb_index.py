# kb_index.py
import json
from pathlib import Path

from langchain_community.document_loaders import TextLoader, PyPDFLoader
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings  # 新包

# kb_index.py 位于 .../kb/kb_index.py
KB_DIR = Path(__file__).resolve().parent          # .../kb
PROJECT_DIR = KB_DIR.parent                       # .../
DOCS_DIR = KB_DIR / "docs"                        # .../kb/docs
IMAGES_JSON = KB_DIR /"images"/"images.json"              # .../kb/images.json
STORE_DIR = PROJECT_DIR / "kb_store"              # .../kb_store

def load_docs() -> list[Document]:
    docs: list[Document] = []

    # md / txt
    for p in list(DOCS_DIR.glob("**/*.md")) + list(DOCS_DIR.glob("**/*.txt")):
        loaded = TextLoader(str(p), encoding="utf-8").load()
        for d in loaded:
            d.metadata.update({"source": str(p), "doc_type": "text"})
        docs.extend(loaded)

    # pdf
    for p in DOCS_DIR.glob("**/*.pdf"):
        loaded = PyPDFLoader(str(p)).load()
        for d in loaded:
            d.metadata.update({
                "source": str(p),
                "doc_type": "pdf",
                "page": d.metadata.get("page", None),
            })
        docs.extend(loaded)

    # images caption
    if IMAGES_JSON.exists():
        items = json.loads(IMAGES_JSON.read_text(encoding="utf-8"))
        for it in items:
            docs.append(Document(
                page_content=it.get("caption", ""),
                metadata={
                    "source": it.get("path", ""),
                    "doc_type": "image",
                    "image_path": it.get("path", "")
                }
            ))

    return docs

def build_chunks(docs: list[Document]) -> list[Document]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=450,
        chunk_overlap=80,
        separators=["\n\n", "\n", "。", "！", "？", ".", " "],
    )
    chunks = splitter.split_documents(docs)
    for i, c in enumerate(chunks):
        src = Path(c.metadata.get("source", "unknown")).name
        page = c.metadata.get("page", "")
        c.metadata["chunk_id"] = f"{src}|p{page}|c{i}"
    return chunks

def main():
    print("DOCS_DIR =", DOCS_DIR)
    print("IMAGES_JSON =", IMAGES_JSON)
    docs = load_docs()
    print("loaded docs =", len(docs))

    chunks = build_chunks(docs)
    print("built chunks =", len(chunks))

    if not chunks:
        raise RuntimeError(
            f"没有生成任何 chunks：请检查 {DOCS_DIR} 下是否有 md/txt/pdf，或 {IMAGES_JSON} 是否有内容"
        )

    embeddings = HuggingFaceEmbeddings(model_name="BAAI/bge-small-zh-v1.5")
    vs = FAISS.from_documents(chunks, embeddings)
    vs.save_local(str(STORE_DIR))
    print(f"OK: indexed {len(chunks)} chunks -> {STORE_DIR}")

if __name__ == "__main__":
    main()
