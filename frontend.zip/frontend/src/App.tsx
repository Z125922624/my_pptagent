import React, { useMemo, useState } from 'react'
import { generatePptx } from './api'

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}

export default function App() {
  const [prompt, setPrompt] = useState(
    '生成一个关于机器人为主题的PPT，面向非技术同事，9页，偏科普但要专业。'
  )
  const [ensureImage, setEnsureImage] = useState(true)
  const [concurrency, setConcurrency] = useState(4)
  const [baseUrl, setBaseUrl] = useState('http://localhost:8000')

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [lastFilename, setLastFilename] = useState<string | null>(null)

  const canSubmit = useMemo(() => prompt.trim().length > 0 && !loading, [prompt, loading])

  async function onGenerate() {
    setError(null)
    setLastFilename(null)
    setLoading(true)
    try {
      const { blob, filename } = await generatePptx(
        {
          prompt,
          ensure_image: ensureImage,
          concurrency,
        },
        baseUrl
      )
      downloadBlob(blob, filename)
      setLastFilename(filename)
    } catch (e: any) {
      setError(e?.message || String(e))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="page">
      <header className="header">
        <div>
          <h1>ppt-agent</h1>
          <p className="sub">输入一句话需求 → 自动生成 PPTX</p>
        </div>
        <a className="link" href="https://github.com" target="_blank" rel="noreferrer">
          GitHub
        </a>
      </header>

      <main className="card">
        <label className="label">后端地址</label>
        <input
          className="input"
          value={baseUrl}
          onChange={(e) => setBaseUrl(e.target.value)}
          placeholder="http://localhost:8000"
        />

        <label className="label" style={{ marginTop: 14 }}>需求输入</label>
        <textarea
          className="textarea"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          rows={6}
          placeholder="例如：生成一个关于……"
        />

        <div className="row">
          <label className="checkbox">
            <input
              type="checkbox"
              checked={ensureImage}
              onChange={(e) => setEnsureImage(e.target.checked)}
            />
            <span>每页尽量配图（可能触发图片兜底）</span>
          </label>

          <div className="field">
            <label className="label" style={{ margin: 0 }}>并发</label>
            <input
              className="input small"
              type="number"
              min={1}
              max={8}
              value={concurrency}
              onChange={(e) => setConcurrency(Math.max(1, Math.min(8, Number(e.target.value) || 1)))}
            />
          </div>
        </div>

        <button className="btn" disabled={!canSubmit} onClick={onGenerate}>
          {loading ? '生成中…' : '生成并下载 PPTX'}
        </button>

        {error && (
          <div className="alert error">
            <b>生成失败：</b>{error}
          </div>
        )}
        {lastFilename && (
          <div className="alert ok">
            <b>已下载：</b>{lastFilename}
          </div>
        )}

        <div className="tips">
          <div><b>提示</b></div>
          <ul>
            <li>后端默认端口 8000（FastAPI）。</li>
            <li>如果浏览器跨域报错，请确认后端已开启 CORS（本模板已开启 allow_origins=*）。</li>
            <li>生成时间取决于页数/模型/图片生成，属于同步接口（演示用）。</li>
          </ul>
        </div>
      </main>

      <footer className="footer">© {new Date().getFullYear()} ppt-agent</footer>
    </div>
  )
}
