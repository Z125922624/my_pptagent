# write_deck_parallel.py
import asyncio
import random
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, Any, List

from ppt_agent.models import DeckSpec, SlideSpec, Block
from ppt_agent.clients import get_deepseek_async_client
from write_one_slide import write_one_slide

# ✅ 调用 public 函数（建议将 kb_retrieve._seedream_generate_and_save 重命名为 seedream_generate_and_save）
from kb import kb_retrieve

# 定义全局线程池（处理同步IO密集型任务，避免阻塞异步事件循环）
EXECUTOR = ThreadPoolExecutor(max_workers=4)
def _img_path_from_content(c) -> str:
    if c is None:
        return ""
    if isinstance(c, dict):
        return (c.get("path") or "").strip()
    p = getattr(c, "path", "") or ""
    return str(p).strip()

def _img_caption_from_content(c) -> str:
    if c is None:
        return ""
    if isinstance(c, dict):
        return (c.get("caption") or "").strip()
    cap = getattr(c, "caption", "") or ""
    return str(cap).strip()

def _img_path_from_block(b) -> str:
    c = getattr(b, "content", None)
    if c is None:
        return ""
    # dict
    if isinstance(c, dict):
        return (c.get("path") or "").strip()
    # Pydantic / dataclass-like: 优先 path 属性
    p = getattr(c, "path", "") or ""
    return str(p).strip()

def _has_image_block(slide: SlideSpec) -> bool:
    return any(getattr(b, "kind", None) == "image" for b in (slide.blocks or []))


def _assign_template_id(slide: SlideSpec) -> None:
    """为Slide分配模板ID（A/B/C），规则优先，无规则则稳定随机"""
    # 规则：有 cards+fact/example 更适合 A；cards=3 更适合 B；fact 强适合 C
    blocks = slide.blocks or []
    kinds = [b.kind for b in blocks]

    has_cards = "cards" in kinds
    has_fact = "fact" in kinds
    has_example = "example" in kinds

    # 已有合法template_id则不覆盖
    if getattr(slide, "template_id", None) in ("A", "B", "C"):
        return

    if has_fact and not has_cards:
        tid = "C"
    elif has_cards and has_fact and has_example:
        tid = random.choice(["A", "B", "C"])
    else:
        # 稳定随机：按 slide_no 固定种子，避免每次运行结果不同
        r = random.Random(int(slide.slide_no or 0))
        tid = r.choice(["A", "B", "C"])

    slide.template_id = tid


def _pick_unused_images(
        image_hits: List[Dict[str, Any]],
        used_paths: set[str],
        need_n: int,
) -> List[Dict[str, Any]]:
    """从 image_hits 里选 need_n 张没用过的图，返回 [{"path": "...", "caption": "..."}...]"""
    chosen: List[Dict[str, Any]] = []
    if not image_hits or need_n <= 0:
        return chosen

    for hit in image_hits:
        if len(chosen) >= need_n:
            break
        p = (hit.get("image_path") or hit.get("path") or "").strip()
        if not p or p in used_paths:
            continue
        cap = hit.get("caption") or ""
        chosen.append({"path": p, "caption": cap})

    return chosen


async def _async_seedream_generate_and_save(topic, slide_no, slide_title, takeaway_suffix):
    """异步包装图片生成函数，避免阻塞事件循环"""
    try:
        # 同步函数放到线程池执行
        gen_result = await asyncio.get_event_loop().run_in_executor(
            EXECUTOR,
            kb_retrieve.seedream_generate_and_save,  # 改为public函数（去掉下划线）
            topic, slide_no, slide_title, takeaway_suffix
        )
        return gen_result
    except Exception as e:
        print(f"图片生成失败：topic={topic}, slide_no={slide_no}, 错误={str(e)}")
        return {"image_path": "", "caption": f"生成失败：{type(e).__name__}"}


async def _ensure_image_blocks_for_slide(
        slide: SlideSpec,
        pack: Dict[str, Any],
        topic: str,
        used_paths: set[str],
        need_n: int,
        allow_generate: bool = False,  # ✅ 默认就不生成
) -> None:
    """
    Step4 只做“装配”：
    - 同页 image 去重（按 path）
    - 不足 need_n 时，只从 Step3 evidence.image_hits 补齐
    - allow_generate=False 时绝不调用生成
    """
    print(
        f"[ensure] slide {pack.get('slide_no')} tpl={pack.get('template_id')} need_n={need_n} "
        f"before_imgs={[_img_path_from_block(b) for b in slide.blocks if getattr(b, 'kind', None) == 'image']}"
    )
    if need_n <= 0:
        return
    slide.blocks = slide.blocks or []

    # 1) 同页去重：保留第一张出现的 path，后面的重复 image block 全删掉
    new_blocks: List[Block] = []
    local_paths: set[str] = set()

    for b in slide.blocks:
        if getattr(b, "kind", None) != "image":
            new_blocks.append(b)
            continue

        p = _img_path_from_content(getattr(b, "content", None))
        if not p:
            continue
        if p in local_paths:
            continue

        local_paths.add(p)
        new_blocks.append(b)

    slide.blocks = new_blocks

    # 2) 已满足 need_n 就结束；否则用 Step3 的 image_hits 补齐（只做同页去重，不做全局过滤）
    if len(local_paths) >= need_n:
        return

    ev = (pack or {}).get("evidence") or {}
    hits = ev.get("image_hits") or []

    for hit in hits:
        if len(local_paths) >= need_n:
            break
        p = (hit.get("image_path") or hit.get("path") or "").strip()
        if not p or p in local_paths:
            continue
        cap = hit.get("caption") or ""
        slide.blocks.append(Block(kind="image", content={"path": p, "caption": cap}))
        local_paths.add(p)
    print(
        f"[ensure] slide {pack.get('slide_no')} "
        f"after_imgs={[_img_path_from_block(b) for b in slide.blocks if getattr(b, 'kind', None) == 'image']}"
    )
    # 3) allow_generate=False：到这里就结束（不够就不够，渲染端显示占位）
    if not allow_generate:
        return

    # 如果你未来想允许 Step4 兜底生成（目前目标 B 不需要），可以在这里保留生成逻辑


def _normalize_layout_hint(layout_hint: Any) -> str:
    """归一化layout_hint，仅保留cards/process/bullets"""
    ALLOWED_LAYOUT = {"cards", "process", "bullets"}
    lh = (str(layout_hint).strip().lower() if layout_hint is not None else "")
    if lh in ALLOWED_LAYOUT:
        return lh
    # 常见别名映射
    mapping = {
        "consulting": "bullets",
        "mckinsey": "bullets",
        "bcg": "bullets",
        "text": "bullets",
        "card": "cards",
        "steps": "process",
        "flow": "process",
    }
    return mapping.get(lh, "bullets")


def _dict_to_card_text(d: Dict[str, Any]) -> str:
    """将dict转为card的text字段（排除title）"""
    parts = []
    for k, v in d.items():
        if k == "title" or v is None:
            continue
        if isinstance(v, (list, tuple)):
            v = "；".join(str(x) for x in v if x is not None)
        parts.append(str(v))
    return "；".join([p for p in parts if p.strip()]) or ""


def sanitize_slide_dict(s: Dict[str, Any]) -> Dict[str, Any]:
    """清洗slide字典，确保字段符合SlideSpec规范"""
    s = dict(s or {})

    # 1) layout_hint归一化
    s["layout_hint"] = _normalize_layout_hint(s.get("layout_hint"))

    blocks = s.get("blocks") or []
    new_blocks: List[Dict[str, Any]] = []

    for b in blocks:
        if not isinstance(b, dict):
            continue
        b = dict(b)
        kind = str(b.get("kind") or "").strip().lower()
        content = b.get("content")

        # 2) cards：确保list[{"title","text"}]
        if kind == "cards":
            if isinstance(content, list):
                fixed = []
                for item in content:
                    if isinstance(item, dict):
                        title = str(item.get("title") or "").strip()
                        text = item.get("text") or _dict_to_card_text(item)
                        fixed.append({"title": title, "text": str(text)})
                    else:
                        fixed.append({"title": "", "text": str(item)})
                b["content"] = fixed
            else:
                b["content"] = []

        # 3) bullets：确保list[str]
        elif kind == "bullets":
            if isinstance(content, list):
                b["content"] = [str(x) for x in content]
            elif isinstance(content, str):
                b["content"] = [content]
            elif isinstance(content, dict):
                b["content"] = [f"{k}：{v}" for k, v in content.items()]
            else:
                b["content"] = []

        # 4) process：确保list[str]
        elif kind == "process":
            if isinstance(content, list):
                b["content"] = [str(x) for x in content]
            elif isinstance(content, str):
                b["content"] = [content]
            else:
                b["content"] = []

        # 5) image：确保{"path","caption"}
        elif kind == "image":
            if isinstance(content, dict):
                b["content"] = {
                    "path": str(content.get("path") or content.get("image_path") or ""),
                    "caption": str(content.get("caption") or ""),
                }
            else:
                b["content"] = {"path": "", "caption": ""}

        # 6) 其它kind：统一转为str或list[str]
        else:
            if isinstance(content, list):
                b["content"] = [str(x) for x in content]
            elif content is None:
                b["content"] = ""
            else:
                b["content"] = str(content)

        # 7) 自动修正layout_hint
        if kind == "cards" and s.get("layout_hint") == "bullets":
            s["layout_hint"] = "cards"

        new_blocks.append(b)

    s["blocks"] = new_blocks

    # 8) 根据blocks类型推断layout_hint
    kinds = {str(bb.get("kind") or "").lower() for bb in new_blocks}
    if "cards" in kinds and s["layout_hint"] == "bullets":
        s["layout_hint"] = "cards"
    if "process" in kinds and s["layout_hint"] == "bullets":
        s["layout_hint"] = "process"

    return s


async def _wrap_write_one_slide(client, brief, style_guide, pack, sem):
    """包装异步任务，添加异常捕获，避免单个任务失败导致整体挂起"""
    try:
        return await write_one_slide(client, brief, style_guide, pack, sem)
    except Exception as e:
        print(f"生成slide {pack.get('slide_no')} 失败：{str(e)}")
        from write_one_slide import _fallback_slide
        return _fallback_slide(brief, pack)


async def write_deck_parallel(
        brief_obj,
        outline_items,
        evidence_packs: List[Dict[str, Any]],
        concurrency: int = 4,
) -> DeckSpec:
    """
    异步批量生成Deck（并行生成slide，补图，模板分配）
    输入：brief(pydantic/dict) + outline + evidence_packs
    输出：DeckSpec（Pydantic对象）
    """
    # 标准化brief为字典
    brief: dict[str, any] = brief_obj.model_dump() if hasattr(brief_obj, "model_dump") else dict(brief_obj)

    style_guide = {
        "language": brief.get("language", "zh"),
        "tone": brief.get("tone", "professional"),
        "bullets_max": 5,
        "bullet_len_hint": 18,
        "use_conservative_claims_when_no_evidence": True,
        "citation_style": "source_path_only",
        "prefer_visual_blocks": True,
    }

    # 初始化客户端和并发信号量
    client = get_deepseek_async_client()
    sem = asyncio.Semaphore(concurrency)

    # 构建异步任务并执行（添加异常包装）
    tasks = [
        _wrap_write_one_slide(client, brief, style_guide, pack, sem)
        for pack in evidence_packs
    ]
    slide_dicts = await asyncio.gather(*tasks)

    # 清洗slide字典，确保符合规范
    slide_dicts = [sanitize_slide_dict(s) for s in slide_dicts]

    # 转换为SlideSpec对象并按slide_no排序
    slides: List[SlideSpec] = [SlideSpec.model_validate(s) for s in slide_dicts]
    slides.sort(key=lambda x: (x.slide_no or 10 ** 9))

    # 首尾页修饰
    if slides:
        # 标题页
        slides[0].slide_type = "title"
        slides[0].title = f"{brief.get('topic', '主题')}（科普概览）"
        slides[0].citations = []
        if not any(b.kind == "callout" for b in slides[0].blocks):
            slides[0].blocks.insert(0, Block(kind="callout", content=brief.get("goal", "")))
        # 结尾页
        slides[-1].slide_type = "closing"

    # 模板分配 + 异步补图（核心修复：删除嵌套循环，改为单层循环）
    topic = brief.get("topic", "")
    used_paths: set[str] = set()
    pack_by_no = {p.get("slide_no"): p for p in evidence_packs}

    # 定义模板所需图片数量规则（移到循环外，避免重复定义）
    def _need_images_for_template(tid: str) -> int:
        tid = (tid or "A").upper()
        return 2 if tid in ("B", "C") else 1

    # 单层循环处理每页：分配模板 + 补图（核心修复点）
    for s in slides:
        pack = pack_by_no.get(s.slide_no) or {}
        # 分配模板ID
        _assign_template_id(s)
        # 获取当前slide需要的图片数量
        tid = getattr(s, "template_id", None) or pack.get("template_id") or "A"
        need_n = _need_images_for_template(tid)
        # 异步补图（关键：改为异步函数调用）
        await _ensure_image_blocks_for_slide(
            slide=s,
            pack=pack,
            topic=topic,
            used_paths=used_paths,
            need_n=need_n,
            allow_generate=True,
        )

    # 构建最终DeckSpec
    deck = DeckSpec(
        title=f"{brief.get('topic', '主题')}（科普概览）",
        subtitle=f"面向{brief.get('audience', '受众')}",
        slides=slides,
    )
    return deck


# 可选：主函数测试（如需单独运行）
if __name__ == "__main__":
    async def test():
        # 示例入参（需替换为实际值）
        class MockBrief:
            def model_dump(self):
                return {"topic": "测试主题", "audience": "技术人员", "goal": "测试生成Deck"}

        mock_brief = MockBrief()
        mock_evidence_packs = [
            {"slide_no": 1, "slide_title": "测试页1", "takeaway": "测试结论1"},
            {"slide_no": 2, "slide_title": "测试页2", "takeaway": "测试结论2"},
        ]
        deck = await write_deck_parallel(mock_brief, [], mock_evidence_packs, concurrency=2)
        print(f"生成Deck：{deck.title}，共{len(deck.slides)}页")


    asyncio.run(test())